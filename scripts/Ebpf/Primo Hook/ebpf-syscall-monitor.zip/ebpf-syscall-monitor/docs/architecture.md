# Architecture Notes

## Design decisions

### Why bpftrace and not libbpf/C?

bpftrace is the right tool for this stage because:
- Zero compilation step — the script runs directly
- Readable syntax — the hook logic is self-documenting
- Rapid iteration — changing a filter is one line

The tradeoff is that bpftrace programs are interpreted at runtime and cannot be distributed as standalone binaries. For production deployment at scale, the next step is porting to Rust/Aya (covered in Week 2 of the series) or Go/libbpf.

### Why JSONL and not structured binary?

JSONL (one JSON object per line) is the lowest common denominator for SIEM ingestion. Every major SIEM (Elasticsearch, Splunk, Datadog, Loki) accepts JSONL over stdin, file tail, or HTTP. Binary formats like protobuf would be faster but would require custom parsers at every integration point.

### Why tracepoints and not kprobes?

Tracepoints are the stable ABI for eBPF programs — they are defined in the kernel source and guaranteed not to change between minor versions. kprobes hook directly to kernel function symbols, which can change with any kernel update. For a monitoring tool intended to run on multiple kernel versions, tracepoints are the safer choice.

The exception is when we need data not exposed by tracepoints (e.g. resolved IP addresses in sys_connect) — in that case kprobes are necessary, as shown in Week 6 of the series.

## Data flow

```
kernel tracepoints
      │
      ▼ (eBPF program runs in kernel context)
perf_event_array (kernel→userspace ring buffer)
      │
      ▼ (bpftrace reads from ring buffer)
stdout JSONL stream
      │
      ├─► tee → /tmp/ebpf_events.jsonl (persistent log)
      │
      └─► process_events.py (live analysis)
              │
              ├─► stdout (alerts + verbose)
              └─► report (summary statistics)
```

## Overhead estimation

On a standard Ubuntu 22.04 VM with moderate workload (~200 syscalls/sec):

| Resource | Overhead |
|---|---|
| CPU (kernel) | ~0.3% |
| CPU (userspace bpftrace) | ~0.5% |
| Memory | ~12MB |
| Disk (JSONL log) | ~2MB/min at 200 events/sec |

These numbers will vary based on workload. High-frequency syscall environments (e.g. database servers) may need the `open_write` hook filtered more aggressively to reduce output volume.
