#!/usr/bin/env python3
"""
process_events.py

Processes the JSONL output from syscall_monitor.bt.
Provides filtering, statistics, and anomaly detection.

Usage:
    sudo bpftrace ../syscall_monitor.bt 2>/dev/null | python3 process_events.py
    python3 process_events.py --file /tmp/ebpf_events.jsonl
    python3 process_events.py --file /tmp/ebpf_events.jsonl --report
    python3 process_events.py --file /tmp/ebpf_events.jsonl --filter exec --comm bash

MITRE ATT&CK coverage:
    T1059 - Command and Scripting Interpreter (exec events)
    T1027 - Obfuscated Files (open_write to /tmp, /dev/shm)
    T1071 - Application Layer Protocol (connect events)
"""

import sys
import json
import argparse
import fileinput
from collections import defaultdict, Counter
from datetime import datetime


# ── Anomaly rules ─────────────────────────────────────────────────────────────

SUSPICIOUS_PATHS = [
    "/tmp/", "/dev/shm/", "/var/tmp/",
    "/proc/self/mem", "/proc/self/exe",
]

SUSPICIOUS_COMMS = [
    "nc", "ncat", "netcat", "wget", "curl",
    "python", "python3", "perl", "ruby", "php",
    "bash", "sh", "dash", "zsh",
]

SUSPICIOUS_EXEC_PATHS = [
    "/tmp/", "/dev/shm/", "/var/tmp/",
    "/proc/",
]


def ns_to_datetime(ns: int) -> str:
    """Convert nanosecond timestamp to human-readable datetime."""
    try:
        return datetime.fromtimestamp(ns / 1e9).strftime("%Y-%m-%d %H:%M:%S.%f")[:-3]
    except Exception:
        return str(ns)


def is_suspicious(event: dict) -> tuple[bool, str]:
    """
    Apply basic anomaly rules to an event.
    Returns (is_suspicious, reason).
    """
    t = event.get("type", "")
    comm = event.get("comm", "")
    filepath = event.get("file", "")

    # exec from suspicious path
    if t == "exec":
        for path in SUSPICIOUS_EXEC_PATHS:
            if filepath.startswith(path):
                return True, f"exec from suspicious path: {filepath}"

    # write to suspicious path from unexpected comm
    if t == "open_write":
        for path in SUSPICIOUS_PATHS:
            if filepath.startswith(path) and comm not in ("vim", "nano", "emacs", "cp", "mv", "install"):
                return True, f"write to suspicious path {filepath} by {comm}"

    # network connection from shell or interpreter
    if t == "connect":
        if comm in SUSPICIOUS_COMMS:
            return True, f"network connection from {comm}"

    return False, ""


def process_stream(source, args):
    """Process events from a stream (stdin or file)."""
    stats = defaultdict(int)
    comm_counter = Counter()
    file_counter = Counter()
    alerts = []

    for line in source:
        line = line.strip()
        if not line or line in ("MONITOR_START", "MONITOR_END"):
            continue

        try:
            event = json.loads(line)
        except json.JSONDecodeError:
            continue

        event_type = event.get("type", "")
        comm = event.get("comm", "")

        # apply type filter
        if args.filter and event_type != args.filter:
            continue

        # apply comm filter
        if args.comm and comm != args.comm:
            continue

        stats[event_type] += 1
        if comm:
            comm_counter[comm] += 1
        if event.get("file"):
            file_counter[event["file"]] += 1

        # anomaly check
        suspicious, reason = is_suspicious(event)
        if suspicious:
            alert = {**event, "alert": True, "reason": reason}
            alerts.append(alert)
            if not args.report:
                ts = ns_to_datetime(event.get("ts", 0))
                pid = event.get("pid") or 0
                print(f"\033[91m[ALERT] {ts} | {event_type} | pid={pid} | "
                      f"comm={comm} | reason={reason}\033[0m", flush=True)
        else:
            if not args.report and args.verbose:
                ts = ns_to_datetime(event.get("ts", 0))
                pid = event.get("pid") or 0
                detail = event.get("file") or event.get("fd") or event.get("msg", "")
                print(f"[{event_type:12s}] {ts} | pid={pid:6} | "
                      f"comm={comm:20s} | {detail}", flush=True)

    if args.report:
        print_report(stats, comm_counter, file_counter, alerts)


def print_report(stats, comm_counter, file_counter, alerts):
    """Print a summary report."""
    print("\n" + "═" * 60)
    print("  eBPF Syscall Monitor — Summary Report")
    print("═" * 60)

    print("\n📊 Event counts:")
    for event_type, count in sorted(stats.items(), key=lambda x: -x[1]):
        print(f"   {event_type:20s}  {count:6d}")

    print(f"\n🔧 Top 10 processes (by event count):")
    for comm, count in comm_counter.most_common(10):
        bar = "█" * min(count // 5 + 1, 30)
        print(f"   {comm:25s}  {count:5d}  {bar}")

    print(f"\n📁 Top 10 files accessed (write mode):")
    for filepath, count in file_counter.most_common(10):
        print(f"   {count:5d}  {filepath}")

    if alerts:
        print(f"\n🚨 Alerts ({len(alerts)} total):")
        for a in alerts[:20]:
            ts = ns_to_datetime(a.get("ts", 0))
            print(f"   [{ts}] {a.get('type'):12s} pid={a.get('pid'):6} "
                  f"comm={a.get('comm'):20s}  ⚠ {a.get('reason')}")
        if len(alerts) > 20:
            print(f"   ... and {len(alerts) - 20} more alerts.")
    else:
        print("\n✅ No anomalies detected.")

    print("\n" + "═" * 60)


def main():
    parser = argparse.ArgumentParser(
        description="Process eBPF syscall monitor events from syscall_monitor.bt"
    )
    parser.add_argument(
        "--file", "-f",
        help="Input JSONL file (default: stdin)",
        default=None
    )
    parser.add_argument(
        "--filter",
        help="Filter by event type: exec, open_write, connect, exec_failed",
        default=None
    )
    parser.add_argument(
        "--comm",
        help="Filter by process name (comm)",
        default=None
    )
    parser.add_argument(
        "--report", "-r",
        help="Print summary report instead of live output",
        action="store_true"
    )
    parser.add_argument(
        "--verbose", "-v",
        help="Print all events (not just alerts) in live mode",
        action="store_true"
    )
    args = parser.parse_args()

    if args.file:
        with open(args.file, "r") as f:
            process_stream(f, args)
    else:
        process_stream(sys.stdin, args)


if __name__ == "__main__":
    main()
