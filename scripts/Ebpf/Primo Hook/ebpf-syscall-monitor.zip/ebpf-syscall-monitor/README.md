# ebpf-syscall-monitor

> Real-time Linux syscall monitoring for threat detection using eBPF and bpftrace.

Hooks `sys_execve`, `sys_openat` (write mode) and `sys_connect` simultaneously and outputs structured **JSON Lines** (JSONL) ready for SIEM ingestion. Includes a Python processor with live anomaly detection and summary reporting.

Part of the **eBPF Security & Observability** series — [read the full article on LinkedIn](#).

---

## MITRE ATT&CK Coverage

| Hook | Syscall | ATT&CK Technique |
|---|---|---|
| exec | `sys_execve` | T1059 — Command and Scripting Interpreter |
| exec | `sys_execve` | T1106 — Native API |
| open_write | `sys_openat` | T1027 — Obfuscated Files or Information |
| open_write | `sys_openat` | T1083 — File and Directory Discovery |
| connect | `sys_connect` | T1071 — Application Layer Protocol (C2) |
| exec_failed | `sys_execve` return | T1055 — Process Injection (failed exec indicator) |

---

## Requirements

| Component | Version |
|---|---|
| OS | Ubuntu 22.04 LTS (or any Linux with kernel ≥ 5.4) |
| Kernel | 5.4+ (5.15+ recommended) |
| bpftrace | ≥ 0.18 |
| Python | 3.10+ |
| Privileges | root (`sudo`) |

---

## Installation

```bash
# Install bpftrace
sudo apt update
sudo apt install -y bpftrace linux-headers-$(uname -r)

# Verify
bpftrace --version
# bpftrace v0.18.0

# Clone this repository
git clone https://github.com/yourusername/ebpf-syscall-monitor.git
cd ebpf-syscall-monitor
chmod +x run.sh
```

---

## Quick Start

### Live monitoring with anomaly alerts

```bash
sudo ./run.sh
```

Output example:
```
✅  bpftrace v0.18.0
✅  kernel 5.15
✅  output → /tmp/ebpf_events_20250115_090000.jsonl

🔍  Live monitoring active. Press Ctrl+C to stop.
    Alerts are highlighted in red.

[ALERT] 2025-01-15 09:00:12.345 | exec       | pid=14821 | comm=bash | reason=exec from suspicious path: /tmp/payload.sh
[ALERT] 2025-01-15 09:00:12.346 | connect    | pid=14821 | comm=bash | reason=network connection from bash
```

### Run for 60 seconds then print a report

```bash
sudo ./run.sh --report 60
```

Output example:
```
═══════════════════════════════════════════════════════════
  eBPF Syscall Monitor — Summary Report
═══════════════════════════════════════════════════════════

📊 Event counts:
   exec                    847
   open_write              312
   connect                  94
   exec_failed              12

🔧 Top 10 processes (by event count):
   bash                     247  █████████████████████████
   python3                  183  ████████████████████
   vim                       98  ████████████
   curl                      23  ████
   ...

🚨 Alerts (3 total):
   [2025-01-15 09:01:23.456] exec         pid= 14821 comm=bash                 ⚠ exec from suspicious path: /tmp/
   [2025-01-15 09:01:23.457] connect      pid= 14821 comm=bash                 ⚠ network connection from bash
   [2025-01-15 09:01:24.123] open_write   pid= 14821 comm=bash                 ⚠ write to suspicious path /dev/shm/ by bash
```

### Process an existing JSONL file

```bash
sudo ./run.sh --file /tmp/ebpf_events.jsonl
```

### Try it with the sample data

```bash
python3 scripts/process_events.py --file examples/sample_output.jsonl --report
```

---

## Manual Usage

### Run bpftrace directly

```bash
sudo bpftrace syscall_monitor.bt 2>/dev/null | tee /tmp/ebpf_events.jsonl
```

### Filter events with jq

```bash
# All exec events
cat /tmp/ebpf_events.jsonl | jq 'select(.type == "exec")'

# Processes opening files in write mode — sorted by frequency
cat /tmp/ebpf_events.jsonl | jq -r 'select(.type == "open_write") | .comm' \
  | sort | uniq -c | sort -rn

# Network connections by process
cat /tmp/ebpf_events.jsonl | jq -r 'select(.type == "connect") | .comm' \
  | sort | uniq -c | sort -rn
```

### Python processor options

```bash
# Live — only show alerts (default)
sudo bpftrace syscall_monitor.bt 2>/dev/null | python3 scripts/process_events.py

# Live — verbose (all events)
sudo bpftrace syscall_monitor.bt 2>/dev/null | python3 scripts/process_events.py --verbose

# Filter by event type
python3 scripts/process_events.py --file events.jsonl --filter exec

# Filter by process name
python3 scripts/process_events.py --file events.jsonl --comm python3

# Full report
python3 scripts/process_events.py --file events.jsonl --report
```

---

## Repository Structure

```
ebpf-syscall-monitor/
├── syscall_monitor.bt          # Main bpftrace program (4 hooks)
├── run.sh                      # Quick start script
├── scripts/
│   └── process_events.py       # JSONL processor with anomaly detection
├── examples/
│   └── sample_output.jsonl     # Sample events for testing
├── docs/
│   └── architecture.md         # Architecture diagram and design notes
├── LICENSE                     # MIT
└── README.md
```

---

## How It Works

```
┌─────────────────────────────────────────────────┐
│                  Linux Kernel                    │
│                                                  │
│  sys_execve ──┐                                  │
│  sys_openat ──┼──► eBPF hooks (bpftrace)        │
│  sys_connect ─┘         │                       │
│                          │ perf_event_array      │
└──────────────────────────┼──────────────────────┘
                           │
                    ┌──────▼──────┐
                    │  userspace  │
                    │  bpftrace   │
                    │  output     │
                    └──────┬──────┘
                           │ JSONL stream
               ┌───────────┼───────────┐
               │           │           │
          ┌────▼────┐  ┌───▼───┐  ┌───▼──────┐
          │ process │  │  jq   │  │   SIEM   │
          │_events  │  │ filter│  │ (Elastic)│
          │ .py     │  └───────┘  └──────────┘
          └─────────┘
```

Each eBPF hook is a tracepoint attached at the kernel level — **before any userspace agent can suppress or modify the event**. This is the fundamental advantage over traditional EDR agents operating in userspace.

---

## SIEM Integration

The JSONL output can be ingested directly by:

**Elasticsearch / OpenSearch**
```bash
sudo bpftrace syscall_monitor.bt 2>/dev/null | \
  while IFS= read -r line; do
    [[ "$line" == {* ]] && curl -s -X POST "http://localhost:9200/ebpf-events/_doc" \
      -H "Content-Type: application/json" -d "$line" > /dev/null
  done
```

**Splunk HEC**
```bash
sudo bpftrace syscall_monitor.bt 2>/dev/null | \
  while IFS= read -r line; do
    [[ "$line" == {* ]] && curl -s -X POST "https://splunk:8088/services/collector" \
      -H "Authorization: Splunk YOUR_HEC_TOKEN" \
      -d "{\"event\": $line}" > /dev/null
  done
```

---

## Extending the Monitor

To add new syscall hooks, follow this pattern in `syscall_monitor.bt`:

```bpftrace
tracepoint:syscalls:sys_enter_YOUR_SYSCALL
{
  printf("{\"ts\":%lld,\"type\":\"your_type\",\"pid\":%d,\"comm\":\"%s\"}\n",
    nsecs, pid, comm);
}
```

List all available tracepoints:
```bash
sudo bpftrace -l 'tracepoint:syscalls:*' | grep sys_enter
```

---

## Tested Environments

| Environment | Kernel | bpftrace | Status |
|---|---|---|---|
| Ubuntu 22.04 LTS | 5.15.0 | 0.18.0 | ✅ Tested |
| Ubuntu 24.04 LTS | 6.8.0  | 0.21.0 | ✅ Tested |
| Debian 12 | 6.1.0 | 0.19.1 | ✅ Tested |
| Kind (Docker) | 5.15.0 | — | ✅ Tested (host only) |

> **Note:** eBPF tracepoints require access to the host kernel. This tool runs on the **host**, not inside containers.

---

## Contributing

Contributions are welcome. To add a new detection rule to `process_events.py`:

1. Add your pattern to `SUSPICIOUS_PATHS`, `SUSPICIOUS_COMMS`, or extend the `is_suspicious()` function
2. Add a test case in `examples/sample_output.jsonl`
3. Open a PR with a description of the ATT&CK technique the rule covers

---

## Related Articles

This repository is part of a series on eBPF security and observability:

- **Week 1** — [Il tuo primo hook eBPF: monitoraggio syscall con bpftrace in 30 minuti](#) *(this lab)*
- **Week 2** — [Syscall monitor con Rust Aya: programma eBPF type-safe da zero](#)
- **Week 4** — [Lab: deploy di Tetragon in Kubernetes per runtime policy enforcement](#)
- **Week 8** — [Lab: MITRE ATT&CK mapper real-time con bpftrace e Python](#)

---

## License

MIT — see [LICENSE](LICENSE).

---

*If this tool was useful, consider starring the repository and sharing the article. Questions and issues are welcome.*
