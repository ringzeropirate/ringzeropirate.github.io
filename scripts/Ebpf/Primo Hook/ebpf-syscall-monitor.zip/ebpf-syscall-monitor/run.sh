#!/usr/bin/env bash
#
# run.sh — Quick start for ebpf-syscall-monitor
#
# Usage:
#   ./run.sh              → live output with alerts highlighted
#   ./run.sh --report     → run for 60 seconds then print summary report
#   ./run.sh --file       → process an existing JSONL file
#
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
BT_SCRIPT="$SCRIPT_DIR/syscall_monitor.bt"
PY_SCRIPT="$SCRIPT_DIR/scripts/process_events.py"
OUTPUT_FILE="/tmp/ebpf_events_$(date +%Y%m%d_%H%M%S).jsonl"

# ── Checks ────────────────────────────────────────────────────────────────────
if [[ $EUID -ne 0 ]]; then
  echo "❌  This script requires root privileges. Run with: sudo ./run.sh"
  exit 1
fi

if ! command -v bpftrace &>/dev/null; then
  echo "❌  bpftrace not found. Install with: sudo apt install bpftrace"
  exit 1
fi

if ! command -v python3 &>/dev/null; then
  echo "❌  python3 not found. Install with: sudo apt install python3"
  exit 1
fi

KERNEL=$(uname -r | cut -d. -f1-2)
echo "✅  bpftrace $(bpftrace --version 2>&1 | head -1 | awk '{print $2}')"
echo "✅  kernel $KERNEL"
echo "✅  output → $OUTPUT_FILE"
echo ""

# ── Mode: process existing file ───────────────────────────────────────────────
if [[ "${1:-}" == "--file" ]]; then
  FILE="${2:-/tmp/ebpf_events.jsonl}"
  if [[ ! -f "$FILE" ]]; then
    echo "❌  File not found: $FILE"
    exit 1
  fi
  echo "📂  Processing file: $FILE"
  python3 "$PY_SCRIPT" --file "$FILE" --report
  exit 0
fi

# ── Mode: report (run for 60s then summarise) ─────────────────────────────────
if [[ "${1:-}" == "--report" ]]; then
  DURATION="${2:-60}"
  echo "⏱   Running for ${DURATION}s then printing report..."
  echo "    Press Ctrl+C to stop early."
  echo ""
  timeout "$DURATION" bpftrace "$BT_SCRIPT" 2>/dev/null | tee "$OUTPUT_FILE" | \
    python3 "$PY_SCRIPT" --report || true
  exit 0
fi

# ── Mode: live (default) ──────────────────────────────────────────────────────
echo "🔍  Live monitoring active. Press Ctrl+C to stop."
echo "    Alerts are highlighted in red."
echo "    All events are saved to: $OUTPUT_FILE"
echo ""
bpftrace "$BT_SCRIPT" 2>/dev/null | tee "$OUTPUT_FILE" | python3 "$PY_SCRIPT" --verbose
