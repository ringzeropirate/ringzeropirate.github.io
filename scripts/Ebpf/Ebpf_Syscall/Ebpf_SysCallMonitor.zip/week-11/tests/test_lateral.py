#!/usr/bin/env python3
"""Unit test di tools/lateral.py: python3 -m unittest discover -s tests"""
import os
import subprocess
import sys
import unittest

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.join(HERE, "..")
sys.path.insert(0, os.path.join(ROOT, "tools"))
import lateral as lm  # noqa: E402


def kp(func, args, ns="ns", pod="p", t="2026-07-16T08:00:00Z"):
    return {"process_kprobe": {"function_name": func, "args": args,
                               "process": {"binary": "/bin/x", "pod": {"namespace": ns, "name": pod}}},
            "time": t}


def fl(dst, port=80, ns="ns", pod="p", t="2026-07-16T08:00:00Z", verdict="DROPPED", ip="10.0.0.1"):
    return {"flow": {"time": t, "verdict": verdict, "traffic_direction": "EGRESS",
                     "IP": {"destination": ip}, "l4": {"TCP": {"destination_port": port}},
                     "source": {"namespace": ns, "pod_name": pod}, "destination": dst}}


def sig(stage, ts, ns="ns", pod="p", sensor="tetragon"):
    return {"stage": stage, "ts": ts, "namespace": ns, "pod": pod, "sensor": sensor,
            "binary": "", "detail": "", "dst": f"x:{ts}"}


class TestNormalize(unittest.TestCase):
    def test_token_path_resolved_or_not(self):
        for path in ("/run/secrets/kubernetes.io/serviceaccount/..2026_07_16/token",
                     "/var/run/secrets/kubernetes.io/serviceaccount/token", "/..2026_07_16/token"):
            s = lm.from_tetragon(kp("security_file_permission", [{"file_arg": {"path": path}}, {"int_arg": 4}]))
            self.assertEqual(s["stage"], "credential", path)

    def test_other_files_ignored(self):
        s = lm.from_tetragon(kp("security_file_permission", [{"file_arg": {"path": "/etc/hosts"}}, {"int_arg": 4}]))
        self.assertIsNone(s)

    def test_api_ports_only(self):
        for port, want in ((443, "discovery"), (6443, "discovery"), (53, None), (8080, None)):
            s = lm.from_tetragon(kp("tcp_connect", [{"sock_arg": {"daddr": "1.2.3.4", "dport": port}}]))
            self.assertEqual(s["stage"] if s else None, want, port)

    def test_events_without_pod_ignored(self):
        ev = kp("tcp_connect", [{"sock_arg": {"daddr": "1.2.3.4", "dport": 443}}])
        ev["process_kprobe"]["process"]["pod"] = {}
        self.assertIsNone(lm.from_tetragon(ev))

    def test_hubble_classification(self):
        self.assertEqual(lm.from_hubble(fl({"labels": ["reserved:kube-apiserver"]}, 6443))["stage"], "discovery")
        self.assertEqual(lm.from_hubble(fl({"namespace": "kube-system", "pod_name": "x"}))["stage"], "lateral")
        self.assertIsNone(lm.from_hubble(fl({"namespace": "ns", "pod_name": "db"}))["stage"])
        self.assertIsNone(lm.from_hubble(fl({"namespace": "other"}, verdict="FORWARDED")))

    def test_timestamps(self):
        base = lm.parse_ts("2026-07-16T08:01:03Z")
        self.assertEqual(base, 1784188863.0)  # UTC, indipendente dal fuso locale
        for s, delta in (("2026-07-16T08:01:03.000400000Z", 0.0004), ("2026-07-16T08:01:03.5Z", 0.5),
                         ("2026-07-16T08:01:03.123Z", 0.123), ("2026-07-16T08:01:03.12345Z", 0.12345),
                         ("2026-07-16T10:01:03+02:00", 0.0), ("2026-07-16T08:01:03", 0.0)):
            self.assertAlmostEqual(lm.parse_ts(s) - base, delta, places=6, msg=s)
        self.assertIsNone(lm.parse_ts("non una data"))
        self.assertIsNone(lm.parse_ts(""))


class TestCorrelation(unittest.TestCase):
    def test_single_stage_never_alerts(self):
        self.assertEqual(lm.correlate([sig("credential", 0), sig("credential", 1)], 120), [])

    def test_two_stages_medium_three_high(self):
        a = lm.correlate([sig("credential", 0), sig("discovery", 5)], 120)
        self.assertEqual(a[0]["severity"], "medium")
        a = lm.correlate([sig("credential", 0), sig("discovery", 5), sig("lateral", 9, sensor="hubble")], 120)
        self.assertEqual(a[0]["severity"], "high")
        self.assertEqual(a[0]["sensors"], ["hubble", "tetragon"])

    def test_window(self):
        self.assertEqual(lm.correlate([sig("credential", 0), sig("discovery", 300)], 120), [])

    def test_alert_time_is_second_distinct_stage(self):
        a = lm.correlate([sig("credential", 0), sig("credential", 1), sig("discovery", 4)], 120)[0]
        self.assertEqual(a["alert_ts"] - a["first_ts"], 4)

    def test_pods_are_isolated(self):
        self.assertEqual(lm.correlate([sig("credential", 0, pod="a"), sig("discovery", 1, pod="b")], 120), [])

    def test_scan_threshold(self):
        flows = [dict(sig(None, t, sensor="hubble"), dst=f"10.0.0.{t}:80") for t in range(3)]
        self.assertEqual([s["stage"] for s in lm.add_scan_signals(flows, 120, 3)][-1], "scan")
        self.assertNotIn("scan", [s["stage"] for s in lm.add_scan_signals(flows[:2], 120, 3)])


class TestCli(unittest.TestCase):
    def run_cli(self, *args):
        return subprocess.run([sys.executable, os.path.join(ROOT, "tools", "lateral.py"), *args],
                              capture_output=True, text=True)

    def test_samples_alert_high_and_negatives_quiet(self):
        r = self.run_cli("--tetragon", os.path.join(ROOT, "samples", "tetragon.jsonl"),
                         "--hubble", os.path.join(ROOT, "samples", "hubble.jsonl"),
                         "--expect-alert", "lm-lab/workload", "--min-severity", "high")
        self.assertEqual(r.returncode, 0, r.stderr)
        self.assertIn("lm-lab/workload", r.stdout)
        self.assertNotIn("lm-quiet", r.stdout)
        self.assertNotIn("lm-slow", r.stdout)

    def test_missing_alert_exit_3(self):
        r = self.run_cli("--tetragon", os.path.join(ROOT, "samples", "tetragon.jsonl"),
                         "--expect-alert", "lm-quiet/app")
        self.assertEqual(r.returncode, 3)

    def test_no_events_exit_2(self):
        r = self.run_cli("--tetragon", os.devnull)
        self.assertEqual(r.returncode, 2)


if __name__ == "__main__":
    unittest.main()
