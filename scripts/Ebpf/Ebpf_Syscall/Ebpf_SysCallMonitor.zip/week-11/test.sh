#!/usr/bin/env bash
# test.sh - Week 11: test end-to-end sul cluster kind-lm-lab.
# Prerequisito: ./setup.sh completato.
#
# Scenari nel pod di prova (lm-lab/workload, usa e getta), solo comandi standard:
#   S1  cat del token del service account          -> credential (Tetragon)
#   S2  curl verso l'API server                    -> discovery  (Tetragon + Hubble DROPPED)
#   S3  curl verso 3 porte di un pod in kube-system -> lateral + scan (Hubble DROPPED)
# Poi: correlazione con tools/lateral.py, atteso un allarme HIGH.
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
export PATH="$SCRIPT_DIR/bin:$PATH"
# shellcheck source=lib.sh
source "$SCRIPT_DIR/lib.sh"

CTX="kind-lm-lab"
POLICY="lm-detections"
TOKEN="/var/run/secrets/kubernetes.io/serviceaccount/token"
k() { kubectl --context "$CTX" "$@"; }

WORK=$(mktemp -d)
TET_PID=""; HUB_PID=""
stop_streams() {
  [[ -n "$TET_PID" ]] && kill "$TET_PID" 2>/dev/null || true
  [[ -n "$HUB_PID" ]] && kill "$HUB_PID" 2>/dev/null || true
  TET_PID=""; HUB_PID=""
}
cleanup() {
  set +e
  stop_streams
  k delete tracingpolicynamespaced "$POLICY" -n lm-lab --ignore-not-found >/dev/null 2>&1
  k delete namespace lm-lab --ignore-not-found --wait=false >/dev/null 2>&1
  rm -rf "$WORK"
}
trap cleanup EXIT

banner "0. Prerequisiti"
k cluster-info >/dev/null 2>&1 || fail "contesto $CTX non raggiungibile: esegui ./setup.sh"
k -n kube-system rollout status ds/cilium --timeout=120s >/dev/null || fail "Cilium non pronto"
k -n kube-system rollout status ds/tetragon --timeout=120s >/dev/null || fail "Tetragon non pronto"
ok "Cilium e Tetragon pronti"

banner "1. Pod di prova e policy di rete"
# Parte sempre da zero: un namespace rimasto da un'esecuzione precedente
# (anche in stato Terminating) farebbe fallire l'apply.
k delete namespace lm-lab --ignore-not-found --wait=true --timeout=180s >/dev/null \
  || fail "il namespace lm-lab di un'esecuzione precedente non si cancella"
k apply -f "$SCRIPT_DIR/k8s/lm-lab.yaml" >/dev/null
k wait --for=condition=Ready pod/workload -n lm-lab --timeout=180s >/dev/null || fail "pod non pronto"
DNS_IP=$(k get pod -n kube-system -l k8s-app=kube-dns -o jsonpath='{.items[0].status.podIP}')
[[ -n "$DNS_IP" ]] || fail "IP del pod CoreDNS non trovato"
ok "pod lm-lab/workload pronto; bersaglio east-west: CoreDNS $DNS_IP"

banner "2. TracingPolicyNamespaced"
k apply -f "$SCRIPT_DIR/policies/lm-detections.yaml" >/dev/null
STATE=""
for _ in $(seq 1 45); do
  STATE=$(k exec -n kube-system ds/tetragon -c tetragon -- tetra tracingpolicy list -o json 2>/dev/null \
    | python3 -c '
import json, sys
try:
    data = json.load(sys.stdin)
except ValueError:
    sys.exit(0)
for p in data.get("policies", []):
    if p.get("name", "").endswith(sys.argv[1]) and p.get("namespace", "") in (sys.argv[2], ""):
        print(p.get("state", "TP_STATE_UNKNOWN"), p.get("error", ""))
' "$POLICY" lm-lab || true)
  case "$STATE" in
    TP_STATE_ENABLED*) break ;;
    TP_STATE_LOAD_ERROR*|TP_STATE_ERROR*) fail "policy in errore: $STATE" ;;
  esac
  sleep 1
done
[[ "$STATE" == TP_STATE_ENABLED* ]] || fail "policy non attiva (stato: '${STATE:-assente}')"
ok "policy attiva"

banner "3. Stream degli eventi"
# kubectl chiamato direttamente (non tramite k) cosi' $! e' il PID di kubectl
kubectl --context "$CTX" exec -n kube-system ds/tetragon -c tetragon -- \
  tetra getevents -o json --namespace lm-lab > "$WORK/tetragon.jsonl" 2>/dev/null &
TET_PID=$!
kubectl --context "$CTX" exec -n kube-system ds/cilium -c cilium-agent -- \
  tail -n 0 -F /var/run/cilium/hubble/events.log > "$WORK/hubble.jsonl" 2>/dev/null &
HUB_PID=$!

# S1 fa da canary: si ripete finche' Tetragon non riporta la lettura del token.
LIVE=""
for _ in $(seq 1 10); do
  k exec -n lm-lab workload -- cat "$TOKEN" >/dev/null
  sleep 3
  if grep -q '"security_file_permission"' "$WORK/tetragon.jsonl" 2>/dev/null; then LIVE=1; break; fi
done
[[ -n "$LIVE" ]] || fail "nessun evento Tetragon: stream non attivo o policy non applicata al pod"
ok "S1 lettura del token osservata (stream attivo)"

banner "4. Scenari di rete (attesi bloccati)"
if k exec -n lm-lab workload -- curl -sk -m 3 -o /dev/null https://kubernetes.default.svc/version 2>/dev/null; then
  warn "S2 chiamata all'API server riuscita: la policy di egress non sta bloccando"
else
  ok "S2 chiamata all'API server tentata e bloccata"
fi
for port in 8080 8181 9153; do
  k exec -n lm-lab workload -- curl -s -m 2 -o /dev/null "http://${DNS_IP}:${port}/" 2>/dev/null || true
done
ok "S3 tre porte di un pod in kube-system tentate"

banner "5. Correlazione"
sleep 5   # tempo per lo scarico degli ultimi eventi
stop_streams
RESULT_DIR="$SCRIPT_DIR/results/$(date -u +%Y%m%dT%H%M%SZ)"
mkdir -p "$RESULT_DIR"
cp "$WORK/tetragon.jsonl" "$WORK/hubble.jsonl" "$RESULT_DIR/"
echo "    eventi Tetragon: $(grep -c . "$RESULT_DIR/tetragon.jsonl" || true), flussi Hubble: $(grep -c . "$RESULT_DIR/hubble.jsonl" || true)"
if python3 "$SCRIPT_DIR/tools/lateral.py" --tetragon "$RESULT_DIR/tetragon.jsonl" \
     --hubble "$RESULT_DIR/hubble.jsonl" --json "$RESULT_DIR/alerts.json" \
     --expect-alert lm-lab/workload --min-severity high > "$RESULT_DIR/report.md"; then
  cat "$RESULT_DIR/report.md"
  ok "allarme HIGH per lm-lab/workload: sequenza correlata da due sensori"
else
  cat "$RESULT_DIR/report.md"
  fail "allarme HIGH atteso non generato (eventi salvati in ${RESULT_DIR#"$SCRIPT_DIR"/})"
fi
ok "risultati in ${RESULT_DIR#"$SCRIPT_DIR"/}"
