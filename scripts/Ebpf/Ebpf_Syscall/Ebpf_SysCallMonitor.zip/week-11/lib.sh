# lib.sh - funzioni comuni agli script della Week 11 (da includere con source)

GREEN='\033[0;32m'; YELLOW='\033[1;33m'; RED='\033[0;31m'
CYAN='\033[0;36m'; BOLD='\033[1m'; RESET='\033[0m'
ok()     { echo -e "${GREEN}OK   $1${RESET}"; }
warn()   { echo -e "${YELLOW}WARN $1${RESET}"; }
fail()   { echo -e "${RED}FAIL $1${RESET}"; exit 1; }
banner() { echo -e "\n${BOLD}${CYAN}--- $1 ---${RESET}"; }

detect_arch() {
  case "$(uname -m)" in
    x86_64)        echo amd64 ;;
    aarch64|arm64) echo arm64 ;;
    *) fail "architettura non supportata: $(uname -m)" ;;
  esac
}
