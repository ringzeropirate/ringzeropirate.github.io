#!/usr/bin/env bash
# teardown.sh - Week 11: elimina il cluster kind del lab. results/ e bin/ restano.
set -euo pipefail
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
export PATH="$SCRIPT_DIR/bin:$PATH"
CLUSTERS=$(kind get clusters 2>/dev/null || true)
if grep -qx "lm-lab" <<<"$CLUSTERS"; then
  kind delete cluster --name lm-lab
  echo "OK   cluster lm-lab eliminato"
else
  echo "OK   cluster lm-lab non presente, niente da fare"
fi
