#!/usr/bin/env bash
# setup.sh - Week 11: kind + Cilium 1.20.3 (Hubble export) + Tetragon 1.7.1
# Prerequisiti: Docker, kubectl, Helm 3, Python 3.8+.
# Ogni comando usa --context kind-lm-lab: il contesto corrente del tuo
# kubeconfig non viene cambiato (tranne da "kind create", come fa sempre kind).
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
export PATH="$SCRIPT_DIR/bin:$PATH"
# shellcheck source=lib.sh
source "$SCRIPT_DIR/lib.sh"

CLUSTER="lm-lab"
CTX="kind-lm-lab"
KIND_VERSION="v0.33.0"
CILIUM_CHART="1.20.3"
TETRAGON_CHART="1.7.1"
k() { kubectl --context "$CTX" "$@"; }
h() { helm --kube-context "$CTX" "$@"; }

echo "Week 11 - Lateral movement: correlazione rete/processo"
echo "======================================================="

for cmd in docker kubectl helm python3 curl; do
  command -v "$cmd" &>/dev/null || fail "$cmd non trovato"
  ok "$cmd trovato"
done
docker info &>/dev/null || fail "Docker non raggiungibile"

banner "kind"
if ! command -v kind &>/dev/null; then
  mkdir -p "$SCRIPT_DIR/bin"
  curl -fsSLo "$SCRIPT_DIR/bin/kind" "https://kind.sigs.k8s.io/dl/${KIND_VERSION}/kind-linux-$(detect_arch)"
  chmod +x "$SCRIPT_DIR/bin/kind"
fi
ok "kind $(kind version | awk '{print $2}')"
CLUSTERS=$(kind get clusters 2>/dev/null || true)
if grep -qx "$CLUSTER" <<<"$CLUSTERS"; then
  warn "cluster $CLUSTER gia' esistente, lo riuso"
else
  kind create cluster --config "$SCRIPT_DIR/k8s/kind-config.yaml"
fi
k cluster-info >/dev/null || fail "kubectl non raggiunge $CTX"
ok "cluster $CTX raggiungibile"

banner "Cilium (CNI + Hubble export)"
helm repo add cilium https://helm.cilium.io >/dev/null 2>&1 || true
helm repo update >/dev/null
if h status cilium -n kube-system &>/dev/null; then
  warn "Cilium gia' installato"
else
  h install cilium cilium/cilium --version "$CILIUM_CHART" --namespace kube-system \
    -f "$SCRIPT_DIR/k8s/cilium-values.yaml"
fi
k -n kube-system rollout status ds/cilium --timeout=300s
k wait --for=condition=Ready nodes --all --timeout=180s >/dev/null
ok "Cilium pronto, nodi Ready"

banner "Tetragon"
if h status tetragon -n kube-system &>/dev/null; then
  warn "Tetragon gia' installato"
else
  h install tetragon cilium/tetragon --version "$TETRAGON_CHART" --namespace kube-system
fi
k -n kube-system rollout status ds/tetragon --timeout=300s
ok "Tetragon pronto"

echo ""
echo "Setup completo. Prossimi passi:"
echo "  ./test.sh       # scenari e correlazione rete/processo"
echo "  ./teardown.sh   # elimina il cluster"
