# Disclaimer

## Italiano

**L'uso di questo codice è sotto la responsabilità esclusiva di chi lo
utilizza.**

Materiale didattico pubblicato nell'ambito della serie "eBPF Security &
Observability", fornito "così com'è", senza garanzie di alcun tipo,
esplicite o implicite. L'autore non è responsabile per danni, perdite,
interruzioni di servizio o conseguenze legali derivanti dall'utilizzo o
dall'utilizzo improprio del materiale.

### Scopo: solo difensivo

Questo lab insegna a **rilevare** il movimento laterale in Kubernetes. Non
insegna a eseguirlo.

- Non contiene exploit, tecniche di escape dal container, pivot verso il
  nodo o codice offensivo di alcun tipo.
- Il token del service account viene letto e scartato (`> /dev/null`): non
  viene mai usato per autenticarsi all'API server né inviato altrove.
- Il pod di prova gira come utente non root, senza capability, senza
  escalation di privilegi, con il service account di default (nessun
  permesso RBAC oltre a quelli concessi di base a ogni utente autenticato).
- Ogni connessione degli scenari viene bloccata dalla network policy del
  lab: lo scopo è generare eventi da correlare, non raggiungere servizi.
- La TracingPolicy osserva soltanto: non blocca, non termina processi, non
  modifica il comportamento del sistema.

### Condizioni d'uso

- Eseguire esclusivamente su sistemi di propria proprietà o per i quali si
  dispone di autorizzazione esplicita e scritta.
- Il lab crea un cluster Kubernetes locale (kind) e installa Cilium e
  Tetragon, che caricano programmi eBPF nel kernel dell'host: usare un
  ambiente di test dedicato, non una macchina di produzione.
- Verificare le leggi applicabili e le policy della propria organizzazione
  prima di eseguire strumenti di sicurezza.
- Gli allarmi prodotti dal correlatore sono segnali da investigare, non
  prove di compromissione.

## English

**Any use of this code is the sole responsibility of the person using it.**

Educational material published as part of the "eBPF Security &
Observability" series, provided "as is", without warranty of any kind,
express or implied. The author accepts no liability for any damage, loss,
service disruption or legal consequence arising from use or misuse.

### Purpose: defensive only

This lab teaches how to **detect** lateral movement in Kubernetes. It does
not teach how to perform it.

- It contains no exploits, container escape techniques, node pivoting or
  offensive code of any kind.
- The service account token is read and discarded (`> /dev/null`): it is
  never used to authenticate to the API server or sent anywhere.
- The test pod runs as a non-root user, with no capabilities, no privilege
  escalation, and the default service account (no RBAC permissions beyond
  the baseline granted to every authenticated user).
- Every connection in the scenarios is blocked by the lab's network policy:
  the goal is to generate events to correlate, not to reach services.
- The TracingPolicy only observes: it does not block, kill processes or
  change system behavior.

### Conditions of use

- Run only on systems you own or are explicitly authorized, in writing, to
  use.
- The lab creates a local Kubernetes cluster (kind) and installs Cilium and
  Tetragon, which load eBPF programs into the host kernel: use a dedicated
  test environment, not a production machine.
- Check applicable laws and your organization's policies before running
  security tooling.
- Alerts produced by the correlator are signals to investigate, not proof
  of compromise.

---

## Verify it yourself

```bash
# The policy has no enforcement actions
grep -nE 'matchActions|Sigkill|Override|Signal|NotifyEnforcer' policies/lm-detections.yaml
# (no output)

# The token is never sent anywhere
grep -rniE 'authorization|bearer' --include='*.sh' --include='*.py' --include='*.yaml' .
# (no output)

# The test pod is non-root with no capabilities
grep -nA11 'securityContext' k8s/lm-lab.yaml
```

See `LICENSE` for the full terms.
