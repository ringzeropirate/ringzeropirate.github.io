# ebpf-syscall-monitor: Week 11

> Detecting lateral movement in Kubernetes with eBPF: network and process correlation

Part of the **eBPF Security & Observability** series by Michele Piccinni (RZP).
Read the full article: [Week 11: lateral movement detection](#)

---

> ## ⚠️ Disclaimer: use at your own risk, defensive use only
>
> **Any use of this code is the sole responsibility of the person using it.**
> *L'uso di questo codice è sotto la responsabilità esclusiva di chi lo utilizza.*
>
> - Educational material, provided "as is", without warranty of any kind.
> - **Defensive only:** this lab detects lateral movement; it contains no
>   exploits, no container escape, no node pivoting, no offensive code.
> - Run only on systems you own or are explicitly authorized to use, in a
>   dedicated test environment (it loads eBPF programs into the host kernel).
> - Full terms in Italian and English, plus commands to verify every claim
>   above: [`DISCLAIMER.md`](DISCLAIMER.md). License: [`LICENSE`](LICENSE).

---

## Contents

1. [The idea](#the-idea)
2. [Scope: what this lab is and is not](#scope-what-this-lab-is-and-is-not)
3. [Quick start](#quick-start)
4. [Verification: what was run, and what was not](#verification-what-was-run-and-what-was-not)
5. [Bugs found in code review](#bugs-found-in-code-review)
6. [Design decisions](#design-decisions)
7. [Limits](#limits)
8. [Files](#files)

---

## The idea

A single signal is noise. Reading a service account token is something many
legitimate apps do; a blocked connection is something a misconfigured app
does. **A sequence of different signals from the same pod, seen by two
independent sensors, within a short window, is a story.**

| Stage | Sensor | Signal | ATT&CK |
|---|---|---|---|
| credential | Tetragon | read of a service account `token` file | T1528 Steal Application Access Token |
| discovery | Tetragon / Hubble | `connect()` to 443/6443, or a dropped flow to `reserved:kube-apiserver` | T1613 Container and Resource Discovery |
| lateral | Hubble | dropped flow to a pod in **another namespace** | TA0008 Lateral Movement (blocked attempt) |
| scan | Hubble | >= 3 distinct blocked destinations in the window | T1046 Network Service Discovery |

An alert fires when one pod shows **at least 2 different stages** within the
window (default 120 s). Severity: 2 stages = medium, 3 or more = high. A
single stage, even repeated a hundred times, never alerts.

---

## Scope: what this lab is and is not

**It is** a detection lab: two eBPF sensors (Tetragon for processes, Cilium
Hubble for network), an observe-only TracingPolicy, a deny-by-default
network policy, and a correlator that turns weak signals into an alert with
a timeline.

**It is not** an attack simulation framework. The scenarios use only
standard commands (`cat`, `curl`) in a disposable pod:

| Scenario | What happens | Why it is harmless |
|---|---|---|
| S1 | the pod reads its own service account token | the output goes to `/dev/null`; the token is never used or sent |
| S2 | `curl` to the API server | blocked by the network policy before leaving the pod |
| S3 | `curl` to three ports of the CoreDNS pod | blocked by the network policy |

The test pod runs as a non-root user (65534) with no capabilities, no
privilege escalation and the `RuntimeDefault` seccomp profile. It uses the
namespace's default service account, which has no RBAC permissions beyond
the baseline granted to every authenticated user.

The editorial plan for this week mentioned pod escape and node pivoting.
They were **deliberately left out**: reproducing them adds risk and nothing
to the detection logic, which only needs the observable signals.

---

## Quick start

```bash
./test-offline.sh      # Python 3.8+ only, no cluster
./setup.sh             # Docker, kubectl, Helm 3: kind + Cilium + Tetragon
./test.sh              # scenarios + correlation, expects a HIGH alert
./teardown.sh          # deletes the kind cluster
```

`setup.sh` and `test.sh` pass `--context kind-lm-lab` (and `--kube-context`
to Helm) on every call: they never switch your current context and never
touch other clusters in your kubeconfig. `test.sh` starts from a clean
namespace every time, so it can be re-run safely.

**No Linux VM?** Push the branch to GitHub. The workflow in
`.github/workflows/week-11-e2e.yml` runs the offline test and the full lab on
a GitHub-hosted `ubuntu-24.04` runner and publishes the `week-11-results`
artifact: raw Tetragon and Hubble events, alerts in JSON, the Markdown
report and component logs.

---

## Verification: what was run, and what was not

Everything below was **executed** in the author's build environment, not
just reviewed.

| Check | How | Result |
|---|---|---|
| Correlator unit tests | `python3 -m unittest`, on **Python 3.8, 3.10 and 3.11**, with `TZ=Europe/Rome` | 15/15 on every version |
| Offline test end to end | `test-offline.sh` on Python 3.8, 3.10, 3.11, and again from a clean extract of the published zip | pass |
| Negative cases | samples include a single-stage pod, a two-stage pod outside the window, a same-namespace drop, a DNS connection | none of them alerts |
| TracingPolicyNamespaced | strict validation against the **Tetragon v1.7.1** CRD schema (unknown fields rejected) | valid |
| CiliumNetworkPolicy | strict validation against the **Cilium v1.20.3** CRD schema | valid |
| Namespace, Pod | strict validation against the Kubernetes JSON schemas | valid |
| Helm values | every key in `k8s/cilium-values.yaml` checked against the chart 1.20.3 `values.yaml` | all exist |
| `setup.sh`, `test.sh` | run with simulated `docker`, `kind`, `helm`, `kubectl` (control flow, explicit context on every call, cleanup) | pass, no orphan processes |
| Shell and workflow | `shellcheck`, `actionlint` | clean |
| Facts the design relies on | read in the upstream sources: projected volume default mode `0644` (Kubernetes `ProjectedVolumeSourceDefaultMode`), `USER curl_user` in the curl image build, `Postfix`/`DPort` operators in the Tetragon 1.7.1 CRD | confirmed |

**Not run here:** the full lab on a real kind cluster. The build
environment has no Docker and its kernel has no kprobe support, so Tetragon
cannot start there. The GitHub workflow exists exactly to close this gap:
run it on your fork and the artifact shows real events from a real kernel.
Please report anything that does not behave as documented.

**About numbers.** The only timings in the report come from the sample
events ("alert after N seconds from the first signal"). They describe the
scenario, not the performance of a pipeline, and are presented as such.

---

## Bugs found in code review

A second review, done before publishing, found real problems. They are
fixed, covered by tests, and listed here because they are useful lessons.

**1. On Python 3.8 to 3.10 every event was silently dropped.** The first
timestamp parser relied on `datetime.fromisoformat`, which before Python
3.11 rejects the `Z` suffix and anything other than 3 or 6 decimal digits.
Tetragon and Hubble emit nanoseconds with `Z`. Result: every event got no
timestamp, was discarded, and the correlator reported "no suspicious
sequence". No error, no crash. Ubuntu 22.04 ships Python 3.10. The parser
now handles the format itself, treats missing time zones as UTC (never
local time), and is tested on 3.8, 3.10 and 3.11 with a non-UTC `TZ`.

**2. The test pod ran as root for no reason.** The first version assumed
root was needed to read the token. It is not: projected volumes default to
mode `0644`. The pod now runs as non-root with no capabilities. Side lesson:
`runAsNonRoot: true` alone would make the kubelet refuse to start this
image, because it declares a non-numeric user (`curl_user`); a numeric
`runAsUser` is required.

**3. Re-running the test failed.** Cleanup deletes the namespace without
waiting; an immediate re-run hit a namespace still in `Terminating` state.
`test.sh` now deletes any leftover namespace and waits before starting.

---

## Design decisions

**`Postfix`, not `Prefix`, for the token.** The token is mounted at
`/var/run/secrets/kubernetes.io/serviceaccount/token`, but that path is a
symlink into a projected volume (`..data` pointing to a timestamped
directory). The kernel sees the real path, so a prefix filter on the
documented path never matches. The policy matches the end of the path.

**Two API ports.** Depending on where service translation happens, the
connect seen by the kernel goes to the service IP on 443 or directly to the
API server backend on 6443. The policy watches both.

**Redundancy on purpose.** The expected HIGH alert needs 3 stages out of 4
possible. If one signal is missing in your setup (for example the API flow
is not labelled `kube-apiserver`), the sequence still holds and the test
still means something.

**A deny policy is also a sensor.** The network side only sees flows the
policy blocks. With egress restricted to DNS, every deviation from expected
behavior becomes an event.

**Stdlib only.** The correlator has no dependencies: nothing to install,
nothing to audit beyond one file.

---

## Limits

- **Per-pod correlation.** A sequence split across pods (token read in one,
  used from another) is not linked. Correlating by service account
  identity is the next step.
- **Blocked traffic only.** Lateral movement over allowed traffic is
  invisible to this lab by design: it needs flow baselines, not deny-based
  detection.
- **Batch correlation.** The correlator runs on files collected at the end
  of the test, not in streaming. Week 12 builds the streaming pipeline.
- **Cluster-dependent signals.** Token path, API port seen by the kernel,
  Hubble labels: all vary with configuration. Filters are tolerant, but the
  end-to-end test on your own cluster is the only check that counts.
- **Lab, not production.** Single node, short-lived cluster, permissive
  defaults elsewhere.

---

## Files

| Path | Purpose |
|---|---|
| `tools/lateral.py` | the correlator (Python 3.8+, stdlib only) |
| `tests/test_lateral.py` | 15 unit tests |
| `samples/` | sample Tetragon and Hubble events, positives and negatives |
| `policies/lm-detections.yaml` | TracingPolicyNamespaced, observe only |
| `k8s/lm-lab.yaml` | test pod (non-root) + CiliumNetworkPolicy (egress DNS only) |
| `k8s/kind-config.yaml` | single node, no default CNI |
| `k8s/cilium-values.yaml` | Cilium 1.20.3 with Hubble static export of dropped flows |
| `test-offline.sh` | unit tests + correlation on samples, no cluster |
| `setup.sh`, `test.sh`, `teardown.sh` | full lab on kind |
| `.github/workflows/week-11-e2e.yml` | the full lab on a GitHub runner |
| `DISCLAIMER.md` | terms of use (IT/EN) and verification commands |
| `LICENSE` | MIT |

Pinned versions: kind v0.33.0, Cilium chart 1.20.3, Tetragon chart 1.7.1,
`curlimages/curl:8.11.1`.
