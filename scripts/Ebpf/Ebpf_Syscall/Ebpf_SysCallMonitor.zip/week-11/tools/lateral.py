#!/usr/bin/env python3
"""
lateral.py - Week 11: correlazione rete/processo per sequenze di
movimento laterale in Kubernetes.

Ingressi (JSON una riga per evento):
  --tetragon FILE   output di `tetra getevents -o json`
  --hubble FILE     export statico di Hubble (flussi DROPPED)

Segnali (fasi), per pod:
  credential  Tetragon: lettura di un token del service account      T1528
  discovery   Tetragon: connect() verso 443/6443 (API server)         T1613
              Hubble:   flusso bloccato verso reserved:kube-apiserver  T1613
  lateral     Hubble:   flusso bloccato verso un altro namespace       TA0008 (tentativo)
  scan        Hubble:   >= N destinazioni distinte bloccate in finestra T1046

Allarme: lo stesso pod mostra almeno 2 fasi diverse entro la finestra.
Severita': 2 fasi = medium, 3 o piu' = high. Un singolo segnale isolato
NON genera allarme: e' la sequenza a fare la differenza.

Exit code: 0 ok, 2 nessun evento letto, 3 allarme atteso mancante (--expect-alert)
Solo libreria standard Python 3.8+.
"""
import argparse
import json
import os
import re
import sys
from collections import defaultdict
from datetime import datetime, timezone

TECH = {
    "credential": ("T1528", "Steal Application Access Token", "credential-access"),
    "discovery": ("T1613", "Container and Resource Discovery", "discovery"),
    "lateral": ("TA0008", "Lateral Movement (tentativo bloccato)", "lateral-movement"),
    "scan": ("T1046", "Network Service Discovery", "discovery"),
}
API_PORTS = {443, 6443}


_TS_RE = re.compile(r"^(\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2})(?:\.(\d+))?(Z|[+-]\d{2}:\d{2})?$")


def parse_ts(s):
    """ISO 8601 (Tetragon/Hubble, fino ai nanosecondi) -> epoch secondi.

    Scritta a mano invece di affidarsi a datetime.fromisoformat: fino a
    Python 3.10 fromisoformat accetta solo 3 o 6 cifre decimali e non
    accetta la "Z", e Ubuntu 22.04 usa Python 3.10. Senza fuso orario
    esplicito l'ora e' trattata come UTC, mai come ora locale.
    """
    if not s:
        return None
    m = _TS_RE.match(str(s).strip())
    if not m:
        return None
    base, frac, tz = m.groups()
    micro = (frac or "")[:6].ljust(6, "0")
    tz = "+00:00" if tz in (None, "Z") else tz
    try:
        return datetime.fromisoformat(f"{base}.{micro}{tz}").timestamp()
    except ValueError:
        return None


def read_jsonl(path):
    out, bad = [], 0
    if not path:
        return out, bad
    with open(path, encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            try:
                ev = json.loads(line)
            except ValueError:
                bad += 1
                continue
            if isinstance(ev, dict):
                out.append(ev)
    return out, bad


# ------------------------------------------------------------- normalizzazione

def from_tetragon(ev):
    k = ev.get("process_kprobe")
    if not k:
        return None
    proc = k.get("process") or {}
    pod = proc.get("pod") or {}
    if not pod.get("name"):
        return None
    args = k.get("args") or []
    func = k.get("function_name", "")
    base = {"ts": parse_ts(ev.get("time")), "sensor": "tetragon",
            "namespace": pod.get("namespace", ""), "pod": pod.get("name", ""),
            "binary": proc.get("binary", "")}
    if func == "security_file_permission" and args:
        path = (args[0].get("file_arg") or {}).get("path", "")
        if path.endswith("/token"):
            return dict(base, stage="credential", detail=f"lettura {path}")
    if func == "tcp_connect" and args:
        sock = args[0].get("sock_arg") or {}
        if int(sock.get("dport") or 0) in API_PORTS:
            return dict(base, stage="discovery", dst=f"{sock.get('daddr')}:{sock.get('dport')}",
                        detail=f"connect verso {sock.get('daddr')}:{sock.get('dport')}")
    return None


def from_hubble(ev):
    fl = ev.get("flow") or {}
    if fl.get("verdict") != "DROPPED" or fl.get("traffic_direction", "EGRESS") != "EGRESS":
        return None
    src, dst = fl.get("source") or {}, fl.get("destination") or {}
    if not src.get("pod_name"):
        return None
    l4 = fl.get("l4") or {}
    port = (l4.get("TCP") or l4.get("UDP") or {}).get("destination_port")
    ip = (fl.get("IP") or {}).get("destination", "")
    base = {"ts": parse_ts(fl.get("time") or ev.get("time")), "sensor": "hubble",
            "namespace": src.get("namespace", ""), "pod": src.get("pod_name", ""),
            "binary": "", "dst": f"{ip}:{port}"}
    labels = dst.get("labels") or []
    if any(lbl.startswith("reserved:kube-apiserver") for lbl in labels):
        return dict(base, stage="discovery", detail=f"bloccato verso API server {ip}:{port}")
    if dst.get("namespace") and dst.get("namespace") != src.get("namespace"):
        target = f"{dst.get('namespace')}/{dst.get('pod_name', '?')}"
        return dict(base, stage="lateral", detail=f"bloccato verso {target} {ip}:{port}")
    return dict(base, stage=None, detail=f"bloccato verso {ip}:{port}")   # utile solo per lo scan


# -------------------------------------------------------------------- analisi

def add_scan_signals(signals, window, threshold):
    """Aggiunge un segnale 'scan' quando un pod accumula >= threshold
    destinazioni distinte bloccate in una finestra."""
    by_pod = defaultdict(list)
    for s in signals:
        if s["sensor"] == "hubble" and s["ts"] is not None:
            by_pod[(s["namespace"], s["pod"])].append(s)
    extra = []
    for key, flows in by_pod.items():
        flows.sort(key=lambda s: s["ts"])
        for i, first in enumerate(flows):
            dsts = {f["dst"] for f in flows[i:] if f["ts"] - first["ts"] <= window}
            if len(dsts) >= threshold:
                last = max(f["ts"] for f in flows[i:] if f["ts"] - first["ts"] <= window)
                extra.append({"ts": last, "sensor": "hubble", "namespace": key[0], "pod": key[1],
                              "binary": "", "stage": "scan",
                              "detail": f"{len(dsts)} destinazioni distinte bloccate in {last - first['ts']:.1f}s"})
                break
    return signals + extra


def correlate(signals, window):
    by_pod = defaultdict(list)
    for s in signals:
        if s.get("stage") and s["ts"] is not None:
            by_pod[(s["namespace"], s["pod"])].append(s)
    alerts = []
    for (ns, pod), sigs in sorted(by_pod.items()):
        sigs.sort(key=lambda s: s["ts"])
        best = None
        for i, first in enumerate(sigs):
            win = [s for s in sigs[i:] if s["ts"] - first["ts"] <= window]
            stages = {s["stage"] for s in win}
            if len(stages) >= 2 and (best is None or len(stages) > len(best["stages"])):
                # istante in cui la sequenza diventa allarme: secondo stadio distinto
                seen, fired = set(), None
                for s in win:
                    seen.add(s["stage"])
                    if len(seen) == 2:
                        fired = s["ts"]
                        break
                best = {"namespace": ns, "pod": pod, "stages": sorted(stages),
                        "severity": "high" if len(stages) >= 3 else "medium",
                        "first_ts": first["ts"], "alert_ts": fired,
                        "span": win[-1]["ts"] - first["ts"],
                        "sensors": sorted({s["sensor"] for s in win}),
                        "timeline": win}
        if best:
            alerts.append(best)
    return alerts


def iso(ts):
    return datetime.fromtimestamp(ts, timezone.utc).strftime("%H:%M:%S.%f")[:-3] if ts else "-"


def report(alerts, n_events, window):
    out = ["# Lateral movement: correlazione rete/processo (Week 11)", "",
           f"Eventi letti: {n_events}. Finestra di correlazione: {window:g}s.", ""]
    if not alerts:
        out += ["Nessuna sequenza sospetta.", ""]
        return "\n".join(out) + "\n"
    for a in alerts:
        out.append(f"## {a['namespace']}/{a['pod']}: severita' {a['severity'].upper()}")
        out.append("")
        out.append(f"- Fasi: {', '.join(a['stages'])}")
        out.append(f"- Sensori: {', '.join(a['sensors'])}")
        out.append(f"- Allarme dopo {a['alert_ts'] - a['first_ts']:.3f}s dal primo segnale; "
                   f"sequenza osservata su {a['span']:.3f}s")
        out.append("")
        out.append("| Ora (UTC) | Sensore | Fase | ATT&CK | Dettaglio |")
        out.append("|---|---|---|---|---|")
        for s in a["timeline"]:
            tid, name, _ = TECH[s["stage"]]
            who = f" `{s['binary']}`" if s["binary"] else ""
            out.append(f"| {iso(s['ts'])} | {s['sensor']} | {s['stage']} | {tid} {name} | {s['detail']}{who} |")
        out.append("")
    return "\n".join(out) + "\n"


def main():
    ap = argparse.ArgumentParser(description="Correlazione rete/processo per lateral movement")
    ap.add_argument("--tetragon", help="JSONL di tetra getevents -o json")
    ap.add_argument("--hubble", help="JSONL dell'export Hubble")
    ap.add_argument("--window", type=float, default=120.0, help="finestra in secondi (default 120)")
    ap.add_argument("--scan-threshold", type=int, default=3, help="destinazioni distinte per 'scan'")
    ap.add_argument("--json", help="scrive gli allarmi anche in JSON")
    ap.add_argument("--expect-alert", metavar="NS/POD", help="fallisce se il pod non ha un allarme")
    ap.add_argument("--min-severity", choices=["medium", "high"], default="medium")
    a = ap.parse_args()
    if not a.tetragon and not a.hubble:
        ap.error("serve almeno uno tra --tetragon e --hubble")

    tet, bad_t = read_jsonl(a.tetragon)
    hub, bad_h = read_jsonl(a.hubble)
    if bad_t or bad_h:
        print(f"lateral: righe non JSON ignorate: tetragon {bad_t}, hubble {bad_h}", file=sys.stderr)
    signals = [s for s in (from_tetragon(e) for e in tet) if s]
    signals += [s for s in (from_hubble(e) for e in hub) if s]
    if not tet and not hub:
        print("lateral: nessun evento letto", file=sys.stderr)
        return 2
    signals = add_scan_signals(signals, a.window, a.scan_threshold)
    alerts = correlate(signals, a.window)

    if a.json:
        with open(a.json, "w", encoding="utf-8") as f:
            json.dump(alerts, f, indent=2, default=str)
    try:
        sys.stdout.write(report(alerts, len(tet) + len(hub), a.window))
        sys.stdout.flush()
    except BrokenPipeError:
        devnull = os.open(os.devnull, os.O_WRONLY)
        os.dup2(devnull, sys.stdout.fileno())

    if a.expect_alert:
        rank = {"medium": 1, "high": 2}
        ok = any(f"{al['namespace']}/{al['pod']}" == a.expect_alert
                 and rank[al["severity"]] >= rank[a.min_severity] for al in alerts)
        if not ok:
            print(f"lateral: nessun allarme >= {a.min_severity} per {a.expect_alert}", file=sys.stderr)
            return 3
    return 0


if __name__ == "__main__":
    sys.exit(main())
