#!/usr/bin/env bash
# test-offline.sh - Week 11: verifica il correlatore SENZA cluster,
# su eventi Tetragon e Hubble di esempio (positivi e negativi).
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
# shellcheck source=lib.sh
source "$SCRIPT_DIR/lib.sh"

command -v python3 &>/dev/null || fail "python3 non trovato"
WORK=$(mktemp -d)
trap 'rm -rf "$WORK"' EXIT

banner "1. Unit test"
RC=0
python3 -m unittest discover -s "$SCRIPT_DIR/tests" -p 'test_*.py' > "$WORK/ut.log" 2>&1 || RC=$?
tail -3 "$WORK/ut.log"
[[ $RC -eq 0 ]] || { cat "$WORK/ut.log"; fail "unit test falliti"; }
ok "unit test superati"

banner "2. Correlazione sugli eventi di esempio"
python3 "$SCRIPT_DIR/tools/lateral.py" \
  --tetragon "$SCRIPT_DIR/samples/tetragon.jsonl" --hubble "$SCRIPT_DIR/samples/hubble.jsonl" \
  --json "$WORK/alerts.json" --expect-alert lm-lab/workload --min-severity high \
  || fail "allarme HIGH atteso per lm-lab/workload non generato"

python3 - "$WORK/alerts.json" <<'PY' || fail "allarmi diversi dall'atteso"
import json, sys
alerts = json.load(open(sys.argv[1]))
pods = sorted(f"{a['namespace']}/{a['pod']}" for a in alerts)
assert pods == ["lm-lab/workload"], f"pod in allarme: {pods} (attesi solo lm-lab/workload)"
a = alerts[0]
assert a["stages"] == ["credential", "discovery", "lateral", "scan"], a["stages"]
assert a["sensors"] == ["hubble", "tetragon"], a["sensors"]
print("1 solo allarme, 4 fasi, 2 sensori; i casi negativi (fase singola, fuori finestra) restano muti")
PY
ok "correlazione verificata"

echo ""
ok "test-offline completato"
