# ebpf-syscall-monitor — Week 03

> Bypassing Obfuscated Malware Detection with eBPF Syscall Tracing

Part of the **eBPF Security & Observability** series.
Read the full article: [Week 3 — Bypassing Obfuscated Malware Detection](#)

---

## ⚠️ Safety Warning

**Run everything in an isolated VM without external networking.**
The simulator replicates T1027 syscall patterns for educational purposes only.
Never run on production systems.

---

## What this lab demonstrates

| Tool | Static detection | Runtime detection | Overhead |
|---|---|---|---|
| Signature AV / YARA | ❌ 0 alerts | ❌ not monitored | low |
| strace | N/A | ✅ sees everything | ~30% CPU |
| **eBPF (bpftrace)** | N/A | ✅ **< 800ms** | **< 1%** |

The simulator (`malware_sim.c`) has all strings XOR-encoded — `strings(1)` reveals nothing suspicious. Only the syscall sequence betrays the behavior, and only eBPF catches it automatically across all processes.

---

## Requirements

```bash
sudo apt install -y bpftrace strace yara gcc linux-headers-$(uname -r)
```

| Component | Version |
|---|---|
| OS | Ubuntu 22.04 LTS (isolated VM) |
| Kernel | ≥ 5.15 |
| bpftrace | ≥ 0.18 |

---

## Quick start

```bash
# Clone and enter week-03
git clone https://github.com/YOURUSERNAME/ebpf-syscall-monitor.git
cd ebpf-syscall-monitor
git checkout week-03

# Run the automated lab (requires root)
chmod +x test.sh
sudo ./test.sh
```

---

## Manual step-by-step

### 1. Build the simulator

```bash
gcc -O2 -s -o malware_sim malware_sim.c
```

### 2. Verify static analysis finds nothing

```bash
strings malware_sim | grep -iE "exec|shell|payload|mmap"
# Expected: only GLIBC references, no readable suspicious strings

yara loader_rule.yar malware_sim
# Expected: (no output — no matches)
```

### 3. Launch the eBPF detector (Terminal 1)

```bash
sudo bpftrace detector_t1027.bt
```

Wait for:
```
Attaching 5 probes...
Detector T1027 attivo.
```

### 4. Run the simulator (Terminal 2)

```bash
./malware_sim
```

### 5. Observe the alert (Terminal 1)

```
⚠️  ALERT T1027 — mprotect(EXEC)
  pid      : 12252
  comm     : malware_sim
  addr     : 0x767c6a2dd000
  prot     : 0x5  (EXEC=1 WRITE=0 READ=1)
  pattern  : mmap(ANON+W) → mprotect(EXEC) ◀ SOSPETTO
  mitre    : T1027 Obfuscated Files / T1055 Process Injection
```

---

## Files

| File | Description |
|---|---|
| `malware_sim.c` | XOR-obfuscated loader simulator — replicates T1027 syscall pattern |
| `detector_t1027.bt` | Main eBPF detector — human-readable alert output |
| `detector_t1027_json.bt` | Same detector — JSONL output for SIEM ingestion |
| `detector_extended.bt` | Extended detector — T1027 + T1055 + T1055.001 (ptrace) |
| `loader_rule.yar` | YARA rules for static analysis comparison |
| `test.sh` | Automated lab script — runs all tests in sequence |

---

## MITRE ATT&CK Coverage

| Detector | Pattern | Technique |
|---|---|---|
| `detector_t1027.bt` | `mmap(ANON+W)` → `mprotect(EXEC)` | T1027 — Obfuscated Files or Information |
| `detector_extended.bt` | `memfd_create` → `mprotect(EXEC)` | T1055 — Process Injection |
| `detector_extended.bt` | `ptrace(PTRACE_ATTACH)` | T1055.001 — Process Injection via ptrace |

---

## Technical notes

**Why `args->start` not `args->addr` for mprotect?**
The `sys_enter_mprotect` tracepoint exposes the first argument as `start` (matching the syscall signature `mprotect(unsigned long start, ...)`). Verify on your kernel:
```bash
cat /sys/kernel/debug/tracing/events/syscalls/sys_enter_mprotect/format
```

**Why store a flag (1) instead of the mmap address?**
At `sys_enter_mmap`, `args->addr` is the *hint* address — `NULL` (0) for anonymous mappings. Storing 0 and checking `> 0` always fails. We store `1` as a boolean flag instead.

**Why `interval:s:1`?**
Some bpftrace versions exit when no events fire for a period. The keepalive interval prevents premature exit.

---

## Series

| Week | Article | Branch |
|---|---|---|
| Week 1 | bpftrace syscall monitor | `week-01` |
| Week 2 | Rust Aya syscall monitor | `week-02` |
| **Week 3** | **Obfuscated malware detection** *(this lab)* | `week-03` |
| Week 4 | Tetragon in Kubernetes | `week-04` |

---

## License

MIT
