#!/usr/bin/env bash
# test.sh — esegue il lab W3-GIO in sequenza automatica
#
# ⚠️  Eseguire ESCLUSIVAMENTE in VM isolata senza rete esterna.
#
# Uso:
#   chmod +x test.sh
#   ./test.sh
#
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
SIM_BIN="$SCRIPT_DIR/malware_sim"
DETECTOR="$SCRIPT_DIR/detector_t1027.bt"

# ── Colori ────────────────────────────────────────────────────────────────────
RED='\033[0;31m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'
CYAN='\033[0;36m'; BOLD='\033[1m'; RESET='\033[0m'

banner() { echo -e "\n${BOLD}${CYAN}━━━  $1  ━━━${RESET}\n"; }
ok()     { echo -e "${GREEN}✅  $1${RESET}"; }
warn()   { echo -e "${YELLOW}⚠️   $1${RESET}"; }
fail()   { echo -e "${RED}❌  $1${RESET}"; }

# ── Prerequisiti ──────────────────────────────────────────────────────────────
banner "Prerequisiti"

[[ $EUID -eq 0 ]] || { fail "Esegui con sudo"; exit 1; }

for cmd in bpftrace strace yara gcc; do
  command -v "$cmd" &>/dev/null && ok "$cmd trovato" || { fail "$cmd non trovato — installa con: sudo apt install $cmd"; exit 1; }
done

# ── Build simulatore ──────────────────────────────────────────────────────────
banner "Build malware_sim"
gcc -O2 -s -o "$SIM_BIN" "$SCRIPT_DIR/malware_sim.c"
ok "malware_sim compilato"

# ── Test 1: analisi statica ───────────────────────────────────────────────────
banner "Test 1 — Analisi statica (strings + YARA)"

echo "→ strings output:"
strings "$SIM_BIN" | grep -iE "exec|shell|/bin|payload|mmap|step|sim" \
  && warn "Stringhe sospette trovate (simulatore non abbastanza offuscato)" \
  || ok "Nessuna stringa sospetta trovata"

echo ""
echo "→ YARA scan:"
YARA_OUT=$(yara "$SCRIPT_DIR/loader_rule.yar" "$SIM_BIN" 2>/dev/null || true)
if [[ -z "$YARA_OUT" ]]; then
  ok "YARA: nessun match — bypass riuscito"
else
  warn "YARA: match trovati:\n$YARA_OUT"
fi

# ── Test 2: strace ────────────────────────────────────────────────────────────
banner "Test 2 — strace (userspace tracer)"
echo "→ Eseguendo malware_sim con strace (solo mmap/mprotect)..."
echo ""
strace -e trace=mmap,mprotect "$SIM_BIN" 2>&1 \
  | grep -E "mmap|mprotect" \
  | grep -v "^---" \
  | head -20
echo ""
warn "strace richiede attach preventivo + overhead ~30% — non scala"

# ── Test 3: eBPF (background) ─────────────────────────────────────────────────
banner "Test 3 — eBPF detector (kernel-level)"
echo "→ Avvio detector in background per 15 secondi..."
echo ""

ALERT_FILE=$(mktemp)
bpftrace "$DETECTOR" 2>/dev/null > "$ALERT_FILE" &
BPFTRACE_PID=$!

sleep 2  # attendi attach delle probe

echo "→ Eseguendo malware_sim..."
"$SIM_BIN"

sleep 2  # attendi che bpftrace catturi gli eventi

kill "$BPFTRACE_PID" 2>/dev/null || true
wait "$BPFTRACE_PID" 2>/dev/null || true

echo ""
echo "→ Output detector eBPF:"
cat "$ALERT_FILE"
rm -f "$ALERT_FILE"

if grep -q "ALERT" "$ALERT_FILE" 2>/dev/null || \
   cat "$ALERT_FILE" | grep -q "T1027"; then
  ok "eBPF: alert T1027 rilevato!"
else
  # Il file era già rimosso — controlla se l'output era corretto
  echo ""
  warn "Verifica l'output sopra — l'alert dovrebbe mostrare T1027"
fi

# ── Riepilogo ─────────────────────────────────────────────────────────────────
banner "Riepilogo"
echo -e "Strumento        Rilevamento statico   Rilevamento runtime   Overhead"
echo -e "AV/YARA          ❌ 0 match            ❌ non monitora       basso"
echo -e "strace           N/A                   ✅ vede tutto         ~30% CPU"
echo -e "eBPF (bpftrace)  N/A                   ✅ < 800ms            < 1%"
echo ""
ok "Lab completato"
