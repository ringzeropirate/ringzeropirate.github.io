/*
 * loader_rule.yar — regola YARA per il confronto nel lab W3-GIO
 *
 * Questa regola cerca pattern tipici di loader offuscati.
 * Applicata su malware_sim v2 NON produce match — dimostrando
 * che l'offuscamento XOR bypassa la detection statica.
 *
 * Uso:
 *   yara loader_rule.yar /tmp/malware_sim
 *   → (nessun output = nessun match)
 */

rule SuspiciousLoader_XOR
{
    meta:
        description  = "Rileva pattern di loader con decodifica XOR a runtime"
        author       = "Michele Piccinni aka RZP"
        reference    = "MITRE ATT&CK T1027"
        date         = "2026-05-14"

    strings:
        /* Stringhe tipiche di un loader non offuscato */
        $mmap_str    = "mmap" nocase
        $exec_str    = "execve" nocase
        $payload_str = "payload" nocase
        $shell_str   = "/bin/sh" nocase
        $decode_str  = "decode" nocase

        /* Pattern bytecode di loop XOR comune */
        $xor_loop    = { 30 04 0E 48 FF C1 48 39 CE 75 F7 }

        /* Sequenza mmap con flag MAP_ANONYMOUS hardcoded */
        $mmap_anon   = { 48 8D 35 ?? ?? ?? ?? 48 89 C7 }

    condition:
        /* Richiede almeno 2 indicatori per ridurre falsi positivi */
        2 of them
}

rule FilelessLoader_memfd
{
    meta:
        description = "Rileva uso di memfd_create per esecuzione fileless"
        reference   = "MITRE ATT&CK T1055"

    strings:
        $memfd_str   = "memfd_create" nocase
        $shm_path    = "/dev/shm" nocase
        $proc_fd     = "/proc/self/fd" nocase

    condition:
        any of them
}
