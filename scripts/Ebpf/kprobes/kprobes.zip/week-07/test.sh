#!/usr/bin/env bash
# test.sh — esegue il lab W7-GIO in sequenza
# Week 07: process injection detection con eBPF kprobes
#
# ⚠️  Eseguire ESCLUSIVAMENTE in VM isolata.
set -uo pipefail

GREEN='\033[0;32m'; YELLOW='\033[1;33m'; RED='\033[0;31m'
CYAN='\033[0;36m'; BOLD='\033[1m'; RESET='\033[0m'
ok()     { echo -e "${GREEN}OK   $1${RESET}"; }
warn()   { echo -e "${YELLOW}WARN $1${RESET}"; }
fail()   { echo -e "${RED}FAIL $1${RESET}"; }
banner() { echo -e "\n${BOLD}${CYAN}--- $1 ---${RESET}\n"; }

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
SIM="$SCRIPT_DIR/injection_sim"
DETECTOR="$SCRIPT_DIR/detector_injection.bt"

[[ $EUID -eq 0 ]] || { echo "Esegui con sudo"; exit 1; }

# ── Prerequisiti ───────────────────────────────────────────────────────
banner "Prerequisiti"
for cmd in bpftrace gcc; do
  command -v "$cmd" &>/dev/null && ok "$cmd trovato" \
    || { fail "$cmd non trovato - sudo apt install $cmd"; exit 1; }
done

# ── Build simulatore ───────────────────────────────────────────────────
banner "Build injection_sim"
gcc -O2 -o "$SIM" "$SCRIPT_DIR/injection_sim.c" || { fail "Build fallita"; exit 1; }
ok "injection_sim compilato"

# ── Verifica yama per il test ptrace ───────────────────────────────────
YAMA=/proc/sys/kernel/yama/ptrace_scope
if [[ -f "$YAMA" ]]; then
  SCOPE=$(cat "$YAMA")
  if [[ "$SCOPE" -ge 2 ]]; then
    warn "yama ptrace_scope=$SCOPE - il test ptrace fallira"
    warn "Per il lab: sudo sysctl -w kernel.yama.ptrace_scope=0"
  else
    ok "yama ptrace_scope=$SCOPE (compatibile)"
  fi
else
  ok "yama non attivo"
fi

# ── Avvio detector in background ───────────────────────────────────────
banner "Avvio detector eBPF"
ALERTS=$(mktemp)
bpftrace "$DETECTOR" > "$ALERTS" 2>/dev/null &
BPF_PID=$!

cleanup() {
  kill "$BPF_PID" 2>/dev/null || true
  wait "$BPF_PID" 2>/dev/null || true
  rm -f "$ALERTS"
}
trap cleanup EXIT

echo "Attendo attach delle probe (3s)..."
sleep 3
kill -0 "$BPF_PID" 2>/dev/null && ok "Detector attivo (pid $BPF_PID)" \
  || { fail "Detector non partito - controlla: sudo bpftrace $DETECTOR"; exit 1; }

# ── Test 1: memfd fileless ─────────────────────────────────────────────
banner "Test 1 - memfd_create + mprotect(EXEC)"
"$SIM" memfd
sleep 2
grep -q "fileless execution" "$ALERTS" \
  && ok "Alert T1055 fileless rilevato" \
  || warn "Alert non rilevato - verifica output completo a fine test"

# ── Test 2: ptrace ─────────────────────────────────────────────────────
banner "Test 2 - ptrace PTRACE_ATTACH"
"$SIM" ptrace
sleep 2
grep -q "ptrace injection" "$ALERTS" \
  && ok "Alert T1055.008 ptrace rilevato" \
  || warn "Alert non rilevato (possibile restrizione yama)"

# ── Test 3: process_vm_writev ──────────────────────────────────────────
banner "Test 3 - process_vm_writev"
"$SIM" vmwrite
sleep 2
grep -q "cross-process memory write" "$ALERTS" \
  && ok "Alert T1055 cross-process rilevato" \
  || warn "Alert non rilevato"

# ── Output completo ────────────────────────────────────────────────────
banner "Output detector"
cat "$ALERTS"

banner "Riepilogo"
echo "Pattern coperti:"
echo "  T1055.008  ptrace ATTACH / SEIZE / POKEDATA"
echo "  T1055      memfd_create -> mprotect(EXEC)  [fileless]"
echo "  T1055      process_vm_writev               [cross-process]"
