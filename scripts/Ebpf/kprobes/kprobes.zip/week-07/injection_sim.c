/*
 * injection_sim.c — simulatore di process injection per lab W7-GIO
 *
 * Replica i pattern syscall di T1055 SENZA payload dannoso.
 * Tre modalita selezionabili da riga di comando:
 *
 *   ./injection_sim memfd     -> memfd_create + write + mprotect(EXEC)
 *   ./injection_sim ptrace    -> fork + PTRACE_ATTACH sul figlio
 *   ./injection_sim vmwrite   -> fork + process_vm_writev sul figlio
 *
 * ⚠️  USO ESCLUSIVO in VM isolata per scopi didattici.
 *
 * Compilazione:
 *   gcc -O2 -o injection_sim injection_sim.c
 */

#define _GNU_SOURCE
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/mman.h>
#include <sys/ptrace.h>
#include <sys/wait.h>
#include <sys/uio.h>
#include <sys/syscall.h>

/* memfd_create non ha wrapper glibc su alcune versioni */
static int memfd_create_compat(const char *name, unsigned int flags)
{
    return (int)syscall(SYS_memfd_create, name, flags);
}

/* ── Modalita 1: fileless execution via memfd_create ──────────────────── */
static int sim_memfd(void)
{
    printf("[sim] Modalita: memfd_create (T1055 fileless)\n");
    printf("[sim] PID: %d\n", getpid());
    sleep(1);

    printf("[sim] Step 1: memfd_create...\n");
    int fd = memfd_create_compat("payload", 0);
    if (fd < 0) { perror("memfd_create"); return 1; }
    sleep(1);

    printf("[sim] Step 2: write payload nel fd anonimo...\n");
    const char dummy[64] = { 0 };
    if (write(fd, dummy, sizeof(dummy)) < 0) { perror("write"); close(fd); return 1; }
    sleep(1);

    printf("[sim] Step 3: mmap del fd...\n");
    void *mem = mmap(NULL, 4096, PROT_READ | PROT_WRITE, MAP_PRIVATE, fd, 0);
    if (mem == MAP_FAILED) { perror("mmap"); close(fd); return 1; }
    sleep(1);

    printf("[sim] Step 4: mprotect(PROT_EXEC) <- alert atteso qui\n");
    if (mprotect(mem, 4096, PROT_READ | PROT_EXEC) != 0) {
        perror("mprotect");
        munmap(mem, 4096);
        close(fd);
        return 1;
    }
    sleep(1);

    munmap(mem, 4096);
    close(fd);
    printf("[sim] Completato (nessun payload eseguito).\n");
    return 0;
}

/* ── Modalita 2: ptrace attach su processo figlio ─────────────────────── */
static int sim_ptrace(void)
{
    printf("[sim] Modalita: ptrace PTRACE_ATTACH (T1055.008)\n");

    pid_t child = fork();
    if (child < 0) { perror("fork"); return 1; }

    if (child == 0) {
        /* Figlio: aspetta di essere agganciato, poi esce */
        sleep(5);
        _exit(0);
    }

    printf("[sim] Parent PID: %d  Child PID: %d\n", getpid(), child);
    sleep(1);

    printf("[sim] PTRACE_ATTACH sul figlio <- alert atteso qui\n");
    if (ptrace(PTRACE_ATTACH, child, NULL, NULL) < 0) {
        perror("ptrace ATTACH (serve CAP_SYS_PTRACE o yama=0)");
        kill(child, 9);
        waitpid(child, NULL, 0);
        return 1;
    }

    waitpid(child, NULL, 0);
    sleep(1);

    ptrace(PTRACE_DETACH, child, NULL, NULL);
    kill(child, 9);
    waitpid(child, NULL, 0);

    printf("[sim] Completato (nessuna memoria modificata).\n");
    return 0;
}

/* ── Modalita 3: process_vm_writev cross-process ──────────────────────── */
static int sim_vmwrite(void)
{
    printf("[sim] Modalita: process_vm_writev (T1055)\n");

    pid_t child = fork();
    if (child < 0) { perror("fork"); return 1; }

    if (child == 0) {
        volatile char buf[64] = { 0 };
        (void)buf;
        sleep(5);
        _exit(0);
    }

    printf("[sim] Parent PID: %d  Child PID: %d\n", getpid(), child);
    sleep(1);

    char src[16] = "harmless-data";
    struct iovec local  = { .iov_base = src,          .iov_len = sizeof(src) };
    struct iovec remote = { .iov_base = (void *)0x0,  .iov_len = sizeof(src) };

    printf("[sim] process_vm_writev sul figlio <- alert atteso qui\n");
    /* Indirizzo remoto 0x0: la write fallira, ma la syscall viene emessa
     * e il detector eBPF la intercetta comunque — che e il punto del lab. */
    ssize_t n = process_vm_writev(child, &local, 1, &remote, 1, 0);
    if (n < 0)
        printf("[sim] write fallita come atteso (indirizzo remoto non valido)\n");

    sleep(1);
    kill(child, 9);
    waitpid(child, NULL, 0);

    printf("[sim] Completato.\n");
    return 0;
}

int main(int argc, char **argv)
{
    if (argc != 2) {
        fprintf(stderr, "Uso: %s <memfd|ptrace|vmwrite>\n", argv[0]);
        return 2;
    }

    if      (strcmp(argv[1], "memfd")   == 0) return sim_memfd();
    else if (strcmp(argv[1], "ptrace")  == 0) return sim_ptrace();
    else if (strcmp(argv[1], "vmwrite") == 0) return sim_vmwrite();

    fprintf(stderr, "Modalita sconosciuta: %s\n", argv[1]);
    return 2;
}
