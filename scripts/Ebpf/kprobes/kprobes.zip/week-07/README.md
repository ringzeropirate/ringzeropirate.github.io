# ebpf-syscall-monitor — Week 07

> Detecting Process Injection and Memory Manipulation with eBPF kprobes

Part of the **eBPF Security & Observability** series.
Read the full article: [Week 7 — Process injection detection with eBPF](#)

---

## ⚠️ Safety Warning

**Run everything in an isolated VM.**
`injection_sim` replicates T1055 syscall patterns for educational purposes.
It executes no payload and modifies no memory of other processes.
Never run on production systems.

---

## What this lab detects

| Pattern | Syscalls | MITRE ATT&CK |
|---|---|---|
| ptrace attach / seize / pokedata | `ptrace` | T1055.008 — Ptrace System Calls |
| Fileless execution | `memfd_create` → `mprotect(PROT_EXEC)` | T1055 — Process Injection |
| Cross-process memory write | `process_vm_writev` | T1055 — Process Injection |

The fileless pattern is the one no filesystem scanner can see: the payload
lives in an anonymous file descriptor and is never written to disk.

---

## Requirements

| Component | Version |
|---|---|
| OS | Ubuntu 22.04 / 24.04 (isolated VM) |
| Kernel | >= 5.15 |
| bpftrace | >= 0.18 |
| gcc | any recent version |

```bash
sudo apt update
sudo apt install -y bpftrace gcc linux-headers-$(uname -r)
```

---

## Quick start

```bash
git clone https://github.com/YOURUSERNAME/ebpf-syscall-monitor.git
cd ebpf-syscall-monitor
git checkout week-07

chmod +x test.sh
sudo ./test.sh          # builds, runs all three tests, cleans up
```

---

## Manual step-by-step

### 1. Build the simulator

```bash
gcc -O2 -o injection_sim injection_sim.c
```

### 2. Launch the detector (Terminal 1)

```bash
sudo bpftrace detector_injection.bt
```

Wait for:
```
Attaching 6 probes...
=========================================
  Detector Process Injection (T1055)
```

### 3. Run each mode (Terminal 2)

```bash
./injection_sim memfd     # fileless execution
./injection_sim ptrace    # ptrace attach
./injection_sim vmwrite   # cross-process write
```

### 4. Expected alert (Terminal 1)

```
ALERT T1055 - fileless execution
  pid      : 14821
  comm     : injection_sim
  addr     : 0x7f8a1bfff000
  delta_ms : 2041 ms (memfd_create -> mprotect EXEC)
  pattern  : nessun file su disco - invisibile agli scanner
  severity : CRITICAL
```

---

## SIEM integration

```bash
# JSONL to stdout
sudo bpftrace detector_injection_json.bt | jq .

# Ship to Elasticsearch
sudo ./ship_to_elastic.sh
sudo ES_URL=http://es.example:9200 ./ship_to_elastic.sh
```

Sample JSON event:

```json
{"ts":1704067200800456789,"type":"alert","technique":"T1055","pid":14821,
 "comm":"injection_sim","addr":"0x7f8a1bfff000","delta_ms":2041,
 "event":"fileless_exec","severity":"CRITICAL"}
```

---

## Files

| File | Description |
|---|---|
| `injection_sim.c` | Simulator — three modes: `memfd`, `ptrace`, `vmwrite` |
| `detector_injection.bt` | Main detector — human-readable output |
| `detector_injection_json.bt` | Same logic — JSONL for SIEM |
| `ship_to_elastic.sh` | Pipes JSONL alerts into Elasticsearch |
| `test.sh` | Automated lab — builds, tests all modes, cleans up |

---

## Technical notes

**`args->start`, not `args->addr`, for `sys_enter_mprotect`.**
The tracepoint exposes the first argument as `start`. Verify on your kernel:
```bash
cat /sys/kernel/debug/tracing/events/syscalls/sys_enter_mprotect/format
```

**ptrace request constants.**
`PTRACE_ATTACH` = 16, `PTRACE_SEIZE` = 16902, `PTRACE_POKEDATA` = 5.
Full list: `grep PTRACE_ /usr/include/sys/ptrace.h`

**Cast `args->pid` to `int32`.**
The tracepoint field is wider than the actual PID; without the cast the
printed target PID is wrong.

**`interval:s:1` is mandatory.**
Some bpftrace versions exit on inactivity. The keepalive prevents this.

**No ternary operator with strings.**
bpftrace supports `? :` only with numeric values. For conditional strings
use `if / else` with separate `printf` calls — as done in the JSON detector.

**yama may block the ptrace test.**
If `/proc/sys/kernel/yama/ptrace_scope` is 2 or 3, `PTRACE_ATTACH` fails.
For the lab only:
```bash
sudo sysctl -w kernel.yama.ptrace_scope=0
```
Restore afterwards with the original value.

---

## Series

| Week | Branch |
|---|---|
| Week 3 — Obfuscated malware detection | `week-03` |
| Week 6 — XDP and TC filters | `week-06` |
| **Week 7 — Process injection detection** | `week-07` |
| Week 8 — MITRE ATT&CK mapper | `week-08` |

---

## License

MIT
