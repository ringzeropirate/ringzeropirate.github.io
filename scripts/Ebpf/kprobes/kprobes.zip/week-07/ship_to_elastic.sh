#!/usr/bin/env bash
# ship_to_elastic.sh — invia gli alert eBPF a Elasticsearch
# Week 07: process injection detection
#
# Uso:
#   sudo ./ship_to_elastic.sh                       # default localhost:9200
#   sudo ES_URL=http://es.example:9200 ./ship_to_elastic.sh
#
# Ctrl+C per fermare.
set -uo pipefail

ES_URL="${ES_URL:-http://localhost:9200}"
ES_INDEX="${ES_INDEX:-ebpf-injection}"
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
DETECTOR="$SCRIPT_DIR/detector_injection_json.bt"

[[ $EUID -eq 0 ]] || { echo "Esegui con sudo"; exit 1; }

echo "Elasticsearch : $ES_URL"
echo "Indice        : $ES_INDEX"
echo "Detector      : $(basename "$DETECTOR")"
echo ""

# Verifica raggiungibilita ES (non bloccante: gli alert vanno comunque a stdout)
if curl -s --max-time 3 "$ES_URL" >/dev/null 2>&1; then
  echo "Elasticsearch raggiungibile"
else
  echo "ATTENZIONE: Elasticsearch non raggiungibile - gli alert restano su stdout"
fi
echo ""

bpftrace "$DETECTOR" 2>/dev/null | while IFS= read -r line; do
  # Ignora le righe di controllo MONITOR_START / MONITOR_END
  [[ "$line" == \{* ]] || { echo "$line"; continue; }

  echo "$line"

  curl -s --max-time 3 -X POST \
    "$ES_URL/$ES_INDEX/_doc" \
    -H "Content-Type: application/json" \
    -d "$line" >/dev/null 2>&1 \
    || echo "  [ship] invio fallito - alert conservato solo in locale"
done
