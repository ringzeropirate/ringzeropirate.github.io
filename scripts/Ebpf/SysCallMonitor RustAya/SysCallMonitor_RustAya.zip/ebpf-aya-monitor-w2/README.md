# ebpf-aya-monitor — Week 02

> Syscall Monitor with Rust Aya: a type-safe eBPF program from scratch.

Part of the **eBPF Security & Observability** series.
Read the full article: [Week 2 — Syscall Monitor with Rust Aya](#)

---

## ⚠️ Compatibility Note

The aya-rs ecosystem evolves rapidly and git dependencies can generate
version conflicts between releases.

**Use the official template as your starting point** — it is maintained
by the aya-rs team, always aligned with the current git version, and
compiles on the first attempt:

```bash
cargo generate --git https://github.com/aya-rs/aya-template \
  --name ebpf-aya-monitor \
  --define program_type=tracepoint \
  --define tracepoint_category=syscalls \
  --define tracepoint_name=sys_enter_execve
```

Then replace the generated source files with the code in this repository:

| This file | Replace in generated project |
|---|---|
| `src-ebpf/main.rs` | `ebpf-aya-monitor-ebpf/src/main.rs` |
| `src-userspace/main.rs` | `ebpf-aya-monitor/src/main.rs` |
| `src-common/lib.rs` | `ebpf-aya-monitor-common/src/lib.rs` |

Official working examples are also available at:
```bash
git clone https://github.com/aya-rs/aya
ls aya/examples/
```

---

## What this lab does

Hooks `sys_execve` at the kernel level using a bpftrace tracepoint.
Sends `ExecEvent` structs to userspace via `PerfEventArray`.
Outputs structured **JSON Lines** with MITRE ATT&CK technique IDs.

```json
{"type":"exec","pid":12847,"tgid":12847,"uid":1000,
 "comm":"bash","file":"/usr/bin/ls","mitre":"T1059"}
```

---

## Architecture

```
┌─────────────────────────────────┐
│         Linux Kernel            │
│  sys_execve tracepoint          │
│         │                       │
│  eBPF hook (src-ebpf/main.rs)  │
│         │ PerfEventArray        │
└─────────┼───────────────────────┘
          │
  ┌───────▼──────────────────┐
  │  Userspace daemon        │
  │  (src-userspace/main.rs) │
  │         │                │
  │  JSON output → SIEM      │
  └──────────────────────────┘
```

---

## Requirements

| Component | Version |
|---|---|
| OS | Ubuntu 22.04 LTS (kernel ≥ 5.15) |
| Rust | stable + nightly |
| bpf-linker | ≥ 0.9 |
| Privileges | root (`sudo`) |

---

## Quick setup (after cargo generate)

```bash
# 1. Generate the base project
cargo generate --git https://github.com/aya-rs/aya-template \
  --name ebpf-aya-monitor

# 2. Copy our source files
cp src-ebpf/main.rs     ebpf-aya-monitor/ebpf-aya-monitor-ebpf/src/main.rs
cp src-userspace/main.rs ebpf-aya-monitor/ebpf-aya-monitor/src/main.rs
cp src-common/lib.rs    ebpf-aya-monitor/ebpf-aya-monitor-common/src/lib.rs

# 3. Add missing dependencies to ebpf-aya-monitor/Cargo.toml
cd ebpf-aya-monitor
echo 'serde_json = "1"' >> ebpf-aya-monitor/Cargo.toml
echo 'bytes      = "1"' >> ebpf-aya-monitor/Cargo.toml

# 4. Build
cargo build --release

# 5. Run
sudo ./target/release/ebpf-aya-monitor
```

---

## MITRE ATT&CK Coverage

| Hook | Syscall | Technique |
|---|---|---|
| exec via interpreter | `sys_execve` | T1059 — Command and Scripting Interpreter |
| exec from suspicious path | `sys_execve` | T1106 — Native API |
| generic exec | `sys_execve` | T1059.004 — Unix Shell |

---

## Series

| Week | Article | Branch |
|---|---|---|
| Week 1 | [bpftrace syscall monitor](#) | `week-01` |
| **Week 2** | **Rust Aya syscall monitor** *(this lab)* | `week-02` |
| Week 4 | Tetragon in Kubernetes | `week-04` |
| Week 8 | MITRE ATT&CK mapper | `week-08` |

---

## License

MIT
