//! Userspace daemon — ebpf-aya-monitor
//! Week 02: Syscall Monitor with Rust Aya
//!
//! Loads the compiled eBPF bytecode, reads ExecEvent structs
//! from PerfEventArray, and emits JSON Lines on stdout.
//!
//! Usage:
//!   sudo ./ebpf-aya-monitor
//!   sudo ./ebpf-aya-monitor | tee events.jsonl
//!   sudo ./ebpf-aya-monitor | jq 'select(.uid == 0)'
//!
//! ⚠️  Use with the official aya-template:
//!     cargo generate --git https://github.com/aya-rs/aya-template

use anyhow::Context;
use aya::{
    include_bytes_aligned,
    maps::AsyncPerfEventArray,
    programs::TracePoint,
    util::online_cpus,
    Ebpf,
};
use aya_log::EbpfLogger;
use bytes::BytesMut;
use log::{info, warn};
use serde_json::json;
use tokio::{signal, task};

// ── Shared event struct ───────────────────────────────────────────────────────
// Must match ExecEvent in src-ebpf/main.rs exactly.
// repr(C) guarantees identical memory layout on both sides.
#[repr(C)]
#[derive(Clone, Copy)]
struct ExecEvent {
    pid:      u32,
    tgid:     u32,
    uid:      u32,
    filename: [u8; 256],
    comm:     [u8; 16],
}

// Required by Aya to safely read the struct from the ring buffer.
unsafe impl aya::Pod for ExecEvent {}

#[tokio::main]
async fn main() -> anyhow::Result<()> {
    env_logger::init();

    // ── 1. Load compiled eBPF bytecode ────────────────────────────────────
    // OUT_DIR is set by aya-build in build.rs — points to the compiled
    // eBPF ELF object produced by cargo xtask build-ebpf.
    let bpf_bytes = include_bytes_aligned!(
        concat!(env!("OUT_DIR"), "/ebpf-aya-monitor")
    );

    let mut bpf = Ebpf::load(bpf_bytes)
        .context("failed to load eBPF bytecode")?;

    // ── 2. Kernel-side logger ─────────────────────────────────────────────
    if let Err(e) = EbpfLogger::init(&mut bpf) {
        warn!("eBPF kernel logger not available: {}", e);
    }

    // ── 3. Load and attach the tracepoint program ─────────────────────────
    let program: &mut TracePoint = bpf
        .program_mut("ebpf_aya_monitor")
        .context("program 'ebpf_aya_monitor' not found in BPF object")?
        .try_into()?;

    program.load()
        .context("failed to load eBPF program")?;

    program.attach("syscalls", "sys_enter_execve")
        .context("failed to attach to sys_enter_execve")?;

    info!("eBPF monitor active on sys_enter_execve");
    eprintln!("MONITOR_START");

    // ── 4. Open PerfEventArray ────────────────────────────────────────────
    let mut perf_array = AsyncPerfEventArray::try_from(
        bpf.take_map("EXEC_EVENTS")
            .context("EXEC_EVENTS map not found")?,
    )?;

    // ── 5. One async reader task per online CPU ───────────────────────────
    let cpus = online_cpus()
        .map_err(|(_, e)| anyhow::anyhow!(e))?;

    info!("{} online CPUs", cpus.len());

    let mut tasks = Vec::with_capacity(cpus.len());

    for cpu_id in cpus {
        let mut buf = perf_array.open(cpu_id, None)?;

        let t = task::spawn(async move {
            let mut buffers: Vec<BytesMut> = (0..10)
                .map(|_| BytesMut::with_capacity(512))
                .collect();

            loop {
                let events = match buf.read_events(&mut buffers).await {
                    Ok(e)  => e,
                    Err(e) => {
                        eprintln!("CPU {}: read error: {}", cpu_id, e);
                        break;
                    }
                };

                for i in 0..events.read {
                    // SAFETY: the eBPF program wrote a valid ExecEvent.
                    let ptr   = buffers[i].as_ptr() as *const ExecEvent;
                    let event = unsafe { ptr.read_unaligned() };
                    emit_json(&event);
                }
            }
        });

        tasks.push(t);
    }

    // ── 6. Wait for Ctrl+C ────────────────────────────────────────────────
    signal::ctrl_c().await?;
    eprintln!("MONITOR_END");

    Ok(())
}

/// Emit one event as a JSON Line on stdout.
fn emit_json(event: &ExecEvent) {
    let filename = bytes_to_str(&event.filename);
    let comm     = bytes_to_str(&event.comm);

    let out = json!({
        "type":  "exec",
        "pid":   event.pid,
        "tgid":  event.tgid,
        "uid":   event.uid,
        "comm":  comm,
        "file":  filename,
        "mitre": mitre_technique(comm, filename),
    });

    println!("{}", out);
}

/// Convert a null-terminated byte buffer to &str.
fn bytes_to_str(buf: &[u8]) -> &str {
    let end = buf.iter().position(|&b| b == 0).unwrap_or(buf.len());
    std::str::from_utf8(&buf[..end]).unwrap_or("<invalid utf8>")
}

/// Map process/path to the most likely MITRE ATT&CK technique.
fn mitre_technique<'a>(comm: &str, filename: &str) -> &'a str {
    // T1059 — Command and Scripting Interpreter
    const INTERPRETERS: &[&str] = &[
        "bash", "sh", "dash", "zsh", "fish",
        "python3", "python", "perl", "ruby", "php",
        "node", "nodejs", "pwsh",
    ];
    if INTERPRETERS.contains(&comm) {
        return "T1059";
    }

    // T1106 — Native API: exec from suspicious paths
    const SUSPICIOUS: &[&str] = &[
        "/tmp/", "/dev/shm/", "/var/tmp/", "/proc/",
    ];
    if SUSPICIOUS.iter().any(|p| filename.starts_with(p)) {
        return "T1106";
    }

    // Fallback
    "T1059.004"
}
