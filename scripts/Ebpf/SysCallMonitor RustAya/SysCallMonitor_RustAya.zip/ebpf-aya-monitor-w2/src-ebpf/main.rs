//! eBPF kernel-space program — ebpf-aya-monitor
//! Week 02: Syscall Monitor with Rust Aya
//!
//! Hooks sys_enter_execve and sends ExecEvent structs
//! to userspace via PerfEventArray.
//!
//! MITRE ATT&CK: T1059 - Command and Scripting Interpreter
//!               T1106 - Native API
//!
//! ⚠️  Use with the official aya-template:
//!     cargo generate --git https://github.com/aya-rs/aya-template

#![no_std]
#![no_main]

use aya_ebpf::{
    helpers::{
        bpf_get_current_comm,
        bpf_get_current_pid_tgid,
        bpf_get_current_uid_gid,
    },
    macros::{map, tracepoint},
    maps::PerfEventArray,
    programs::TracePointContext,
};
use aya_log_ebpf::info;

/// Event sent to userspace for every sys_execve call.
/// Must match the struct definition in src-userspace/main.rs.
#[repr(C)]
pub struct ExecEvent {
    pub pid:      u32,
    pub tgid:     u32,
    pub uid:      u32,
    pub filename: [u8; 256],
    pub comm:     [u8; 16],
}

/// PerfEventArray: lock-free, per-CPU kernel→userspace channel.
/// Declared as `static` (not `static mut`) — PerfEventArray
/// uses interior mutability internally.
#[map]
static EXEC_EVENTS: PerfEventArray<ExecEvent> = PerfEventArray::new(0);

/// Hook entry point — attached to syscalls/sys_enter_execve.
/// The function name must match bpf.program_mut("ebpf_aya_monitor")
/// in the userspace code.
#[tracepoint]
pub fn ebpf_aya_monitor(ctx: TracePointContext) -> u32 {
    match try_monitor(&ctx) {
        Ok(ret) => ret,
        Err(_)  => 0,
    }
}

fn try_monitor(ctx: &TracePointContext) -> Result<u32, i64> {
    // ── 1. Process identifiers ────────────────────────────────────────────
    let pid_tgid = bpf_get_current_pid_tgid();
    let pid  = (pid_tgid >> 32) as u32;
    let tgid = pid_tgid as u32;
    let uid  = bpf_get_current_uid_gid() as u32;

    // ── 2. Read filename pointer from tracepoint args ─────────────────────
    // sys_enter_execve layout:
    //   offset 0: __syscall_nr (u64)
    //   offset 8: filename     (u64 pointer to char*)
    //   offset 16: argv        (u64)
    //   offset 24: envp        (u64)
    let filename_ptr = unsafe { ctx.read_at::<u64>(8) }
        .map_err(|_| -1i64)?;

    // ── 3. Build the event ────────────────────────────────────────────────
    let mut event = ExecEvent {
        pid,
        tgid,
        uid,
        filename: [0u8; 256],
        comm:     [0u8; 16],
    };

    unsafe {
        aya_ebpf::helpers::bpf_probe_read_user_str_bytes(
            filename_ptr as *const u8,
            &mut event.filename,
        )
    }
    .map_err(|_| -1i64)?;

    event.comm = bpf_get_current_comm().map_err(|_| -1i64)?;

    // ── 4. Kernel-side log ────────────────────────────────────────────────
    info!(ctx, "execve pid={} uid={}", pid, uid);

    // ── 5. Send event to userspace ring buffer ────────────────────────────
    EXEC_EVENTS.output(ctx, &event, 0);

    Ok(0)
}

#[panic_handler]
fn panic(_info: &core::panic::PanicInfo) -> ! {
    unsafe { core::hint::unreachable_unchecked() }
}
