//! Common shared types — ebpf-aya-monitor
//! Week 02: Syscall Monitor with Rust Aya
//!
//! This crate is intentionally minimal. ExecEvent is defined
//! independently in src-ebpf/main.rs and src-userspace/main.rs
//! to avoid cross-compilation complexity in the common crate.
//!
//! Extend this file if you want to share types across crates
//! using the no_std / std feature split pattern.

#![no_std]

// Add shared types here as the project grows.
// Example:
//
// #[repr(C)]
// #[derive(Clone, Copy, Debug)]
// pub struct ExecEvent {
//     pub pid:      u32,
//     pub tgid:     u32,
//     pub uid:      u32,
//     pub filename: [u8; 256],
//     pub comm:     [u8; 16],
// }
//
// #[cfg(feature = "user")]
// unsafe impl aya::Pod for ExecEvent {}
