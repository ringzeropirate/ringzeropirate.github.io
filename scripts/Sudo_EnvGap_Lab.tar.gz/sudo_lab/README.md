# Sudo env_delete Gap Exploitation Lab

## Overview

This lab demonstrates **7 environment variables** missing from sudo's
`initial_badenv_table` (`plugins/sudoers/env.c`) that enable privilege
escalation when `env_reset` is disabled (`Defaults !env_reset`).

**Scenario**: When `env_reset` is OFF, sudo inherits the user's full
environment and relies on the badenv_table (`env_should_delete()`) to
strip dangerous variables. These 7 are not in the table and pass through.

**Note**: With the default `env_reset ON`, the badenv_table is NOT
consulted — the environment is rebuilt from scratch using `env_keep`.
This finding only affects systems with `Defaults !env_reset`.

## Variables NOT blocked (confirmed on 1.9.18rc1 + 1.9.17p2)

| # | Variable | Attack | Risk |
|---|----------|--------|------|
| 1 | `NODE_OPTIONS` | `--require=/tmp/evil.js` | HIGH |
| 2 | `NODE_PATH` | Module resolution from attacker dir | HIGH |
| 3 | `GIT_SSH_COMMAND` | Replace SSH for git operations | HIGH |
| 4 | `_JAVA_OPTIONS` | Legacy JVM `-javaagent` (JAVA_TOOL_OPTIONS IS blocked) | HIGH |
| 5 | `CLASSPATH` | Java class path manipulation | HIGH |
| 6 | `GIT_CONFIG_GLOBAL` | Git config → hooks → RCE | MEDIUM |
| 7 | `PYTHONSTARTUP` | Python startup script (PYTHONPATH IS blocked) | MEDIUM |

**Excluded**: `GCONV_PATH` is stripped by `ld.so` (AT_SECURE), not by sudo.

## Quick Start

```bash
docker build -t sudo-env-lab .
docker run --rm -it sudo-env-lab           # interactive
docker run --rm sudo-env-lab \
  /home/attacker/run_demo.sh --log \
  > sudo_lab_report.log 2>&1               # log for disclosure
```

## Sudo Versions

The Dockerfile builds TWO sudo versions from source:
- `/usr/bin/sudo` → **1.9.18rc1** (development, primary)
- `/opt/sudo-stable/bin/sudo` → **1.9.17p2** (stable, cross-check)

## Defense

```
# Best: keep env_reset ON (the default)
# If !env_reset is required, add:
Defaults env_delete += "NODE_OPTIONS NODE_PATH"
Defaults env_delete += "GIT_SSH_COMMAND GIT_CONFIG_GLOBAL"
Defaults env_delete += "_JAVA_OPTIONS CLASSPATH"
Defaults env_delete += "PYTHONSTARTUP"
```

## Legal Disclaimer

For authorized security research and education only.
