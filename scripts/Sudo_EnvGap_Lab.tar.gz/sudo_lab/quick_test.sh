#!/bin/bash
###############################################################################
# quick_test.sh — Non-interactive verification of sudo env_delete gaps
#
# Run as ROOT on a test system. Creates temp user, tests with !env_reset.
# Usage: sudo bash quick_test.sh
###############################################################################
set -euo pipefail

RED='\033[0;31m'
GREEN='\033[0;32m'
NC='\033[0m'

if [ "$(id -u)" != "0" ]; then
    echo "ERROR: Run as root (sudo bash $0)"
    exit 1
fi

TESTUSER="sudotest$$"
RESULTS=()

cleanup() {
    userdel -r "$TESTUSER" 2>/dev/null || true
    rm -f /etc/sudoers.d/test-envgap 2>/dev/null || true
}
trap cleanup EXIT

echo ""
echo "═══════════════════════════════════════════════════════"
echo "  Sudo env_delete Gap Quick Verification"
echo "  Sudo: $(sudo --version | head -1)"
echo "  Scenario: Defaults !env_reset"
echo "═══════════════════════════════════════════════════════"

useradd -m -s /bin/bash "$TESTUSER"

# Create sudoers rule with !env_reset
cat > /etc/sudoers.d/test-envgap << EOF
Defaults !env_reset
$TESTUSER ALL=(root) NOPASSWD: /usr/bin/env
EOF
chmod 440 /etc/sudoers.d/test-envgap

echo ""
echo "── Testing variables NOT in badenv_table (should PASS) ──"
echo ""
for VAR in NODE_OPTIONS NODE_PATH GIT_SSH_COMMAND _JAVA_OPTIONS CLASSPATH GIT_CONFIG_GLOBAL PYTHONSTARTUP; do
    RESULT=$(su - "$TESTUSER" -c "export $VAR=test_value; sudo /usr/bin/env" 2>&1 | grep "^${VAR}=" || true)
    if [ -n "$RESULT" ]; then
        echo -e "  ${RED}[PASS-THROUGH]${NC} $VAR"
        RESULTS+=("GAP: $VAR")
    else
        echo -e "  ${GREEN}[BLOCKED]${NC}      $VAR"
        RESULTS+=("OK:  $VAR")
    fi
done

echo ""
echo "── Sanity check: badenv_table vars (should be BLOCKED) ──"
echo ""
for VAR in PERL5LIB PYTHONPATH JAVA_TOOL_OPTIONS LD_PRELOAD BASH_ENV; do
    RESULT=$(su - "$TESTUSER" -c "export $VAR=test_value; sudo /usr/bin/env" 2>&1 | grep "^${VAR}=" || true)
    if [ -z "$RESULT" ]; then
        echo -e "  ${GREEN}[BLOCKED]${NC}      $VAR ✓"
    else
        echo -e "  ${RED}[LEAKED]${NC}       $VAR ✗"
    fi
done

GAPS=$(printf '%s\n' "${RESULTS[@]}" | grep -c "^GAP:" || echo 0)
echo ""
echo "═══════════════════════════════════════════════════════"
echo "  Gaps confirmed: $GAPS / 7"
echo "  Cleanup: removing test user and sudoers rule..."
echo "═══════════════════════════════════════════════════════"
